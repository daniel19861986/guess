package com.guessgame.views;

import com.guessgame.controllers.LoginController;
import com.guessgame.controllers.RankingController;
import com.guessgame.services.IconService;
import com.guessgame.services.RankingService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

public class Ranking extends JFrame {
    private Container container = getContentPane();

    public Ranking() {
        setWindowIcon();
        setLayoutManager();
        setTable();
        addComponentsToContainer();
        addActionListeners();
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLayoutManager() {
        container.setLayout(new BorderLayout());
    }

    public static void setTable() {
        RankingService.rankingList = RankingController.getRankings("gameSessions", "score");
        RankingService.rankingList.sort(Comparator.comparing(com.guessgame.models.Ranking::getScore).reversed());

        RankingService.rankingTableColumns = new ArrayList<>();
        RankingService.rankingTableColumns.add("Position");
        RankingService.rankingTableColumns.add("Name");
        RankingService.rankingTableColumns.add("Score");

        ArrayList<String[]> values = new ArrayList<String[]>();
        for (int i = 0; i < RankingService.rankingList.size(); i++) {
            values.add(new String[]{
                    String.valueOf(i + 1),
                    RankingService.rankingList.get(i).getName(),
                    String.valueOf(RankingService.rankingList.get(i).getScore()),
            });
        }

        RankingService.rankingTableModel = new DefaultTableModel(values.toArray(new Object[][]{}), RankingService.rankingTableColumns.toArray());
        RankingService.rankingTable = new JTable((RankingService.rankingTableModel));
    }

    private void addComponentsToContainer() {
        container.add(RankingService.rankingTable.getTableHeader(), BorderLayout.NORTH);
        container.add(RankingService.rankingTable, BorderLayout.CENTER);
        container.add(RankingService.buttonOk, BorderLayout.SOUTH);
    }

    private void addActionListeners(){
        RankingService.buttonOk.addActionListener(RankingService.buttonHandler);
    }
}
