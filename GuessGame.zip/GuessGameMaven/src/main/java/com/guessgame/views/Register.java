package com.guessgame.views;

import com.guessgame.controllers.LoginController;
import com.guessgame.services.AuthService;
import com.guessgame.services.IconService;
import com.guessgame.services.RegisterService;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Register extends JFrame {
    private Container container = getContentPane();

    public Register() {
        setWindowIcon();
        this.getContentPane().setBackground(new Color(0, 128, 0));
        setLayoutManager();
        setDesign();
        setLocationAndSize();
        addComponentsToContainer();
        addActionListeners();
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLayoutManager() {
        container.setLayout(null);
    }

    private void setDesign() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            SwingUtilities.updateComponentTreeUI(Register.this);
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void setLocationAndSize() {
        RegisterService.titleLabel.setBounds(50, 15, 200, 50);

        RegisterService.firstNameLabel.setBounds(50, 110, 160, 30);
        RegisterService.firstNameField.setBounds(170, 110, 200, 32);

        RegisterService.lastNameLabel.setBounds(50, 160, 130, 40);
        RegisterService.lastNameField.setBounds(170, 160, 200, 32);

        RegisterService.emailLabel.setBounds(50, 210, 120, 30);
        RegisterService.emailField.setBounds(170, 210, 200, 32);

        RegisterService.usernameLabel.setBounds(50, 260, 100, 30);
        RegisterService.usernameField.setBounds(170, 260, 200, 32);

        RegisterService.passwordLabel.setBounds(50, 360, 100, 30);
        RegisterService.passwordField.setBounds(170, 360, 200, 32);

        RegisterService.telephoneLabel.setBounds(50, 310, 120, 30);
        RegisterService.telephoneField.setBounds(170, 310, 200, 32);

        RegisterService.dobLabel.setBounds(50, 410, 120, 30);
        RegisterService.dobField.setBounds(170, 410, 200, 32);

        RegisterService.genderLabel.setBounds(50, 460, 120, 30);
        RegisterService.genderField.setBounds(170, 460, 200, 32);

        RegisterService.locationScrollPane.setBounds(500, 110, 200, 200);
        RegisterService.locationLabel.setBounds(425, 110, 150, 30);

        RegisterService.signUpButton.setBounds(50, 550, 90, 30);
        RegisterService.cancelButton.setBounds(250, 550, 80, 30);

        RegisterService.goLogin.setBounds(180, 625, 100, 30);
    }

    public static void setupRegisterTitleLabel(){
        RegisterService.titleLabel.setFont(new Font("Helvetica", Font.BOLD, 30));
    }

    public static void setupRegisterFirstNameLabel(){
        RegisterService.firstNameLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupRegisterLastNameLabel(){
        RegisterService.lastNameLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupRegisterUsernameLabel(){
        RegisterService.usernameLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupRegisterEmailLabel(){
        RegisterService.emailLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupTelephoneLabel(){
        RegisterService.telephoneLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupPasswordLabel(){
        RegisterService.passwordLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupDOBLabel(){
        RegisterService.dobLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupGenderLabel(){
        RegisterService.genderLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupLocationLabel(){
        RegisterService.locationLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupGoLoginLabel(){
        RegisterService.goLogin.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupFirstNameField(){
        RegisterService.firstNameField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupLastNameField(){
        RegisterService.lastNameField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupUsernameField(){
        RegisterService.usernameField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupEmailField(){
        RegisterService.emailField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupPasswordField(){
        RegisterService.passwordField.setFont(new Font("Helvetica", Font.PLAIN, 10));
    }

    public static void setupTelephoneField(){
        RegisterService.telephoneField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupDOBField(){
        RegisterService.dobField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupGenderField(){
        RegisterService.genderField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupLocationField(){
        RegisterService.locationField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupSignUpButtonLabel(){
        RegisterService.signUpButton.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupCancelButtonLabel(){
        RegisterService.cancelButton.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    private void addComponentsToContainer() {
        container.add(RegisterService.titleLabel);

        container.add(RegisterService.firstNameField);
        container.add(RegisterService.firstNameLabel);

        container.add(RegisterService.lastNameField);
        container.add(RegisterService.lastNameLabel);

        container.add(RegisterService.usernameLabel);
        container.add(RegisterService.usernameField);

        container.add(RegisterService.passwordLabel);
        container.add(RegisterService.passwordField);

        container.add(RegisterService.emailLabel);
        container.add(RegisterService.emailField);

        container.add(RegisterService.telephoneLabel);
        container.add(RegisterService.telephoneField);

        container.add(RegisterService.dobField);
        container.add(RegisterService.dobLabel);

        container.add(RegisterService.genderField);
        container.add(RegisterService.genderLabel);

        container.add(RegisterService.locationScrollPane);
        container.add(RegisterService.locationLabel);

        container.add(RegisterService.signUpButton);
        container.add(RegisterService.cancelButton);

        container.add(RegisterService.goLogin);
    }

    private void addActionListeners() {
        RegisterService.signUpButton.addActionListener(AuthService.buttonHandler);
        RegisterService.cancelButton.addActionListener(AuthService.buttonHandler);
        RegisterService.goLogin.addMouseListener(AuthService.labelHandlerRegister);
    }
}
