package com.guessgame.views;

import com.guessgame.controllers.LoginController;
import com.guessgame.services.AboutService;
import com.guessgame.services.IconService;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class About extends JFrame {

    Container container = getContentPane();

    public About() {
        setWindowIcon();
        addComponentsToContainer();
        setLayoutManager();
        setLocationAndSize();
        addActionListeners();
        getContentPane().setBackground(new Color(0, 128, 0));
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLayoutManager(){
        container.setLayout(null);
    }

    private void setLocationAndSize(){
        AboutService.titleLabel.setBounds(50, 15, 200, 50);
        AboutService.scroll.setBounds(25, 75, 695, 500);
        AboutService.buttonOk.setBounds(320, 600, 70, 30);
    }

    public static void setupTitleLabelAbout(){
        AboutService.titleLabel.setFont(new Font("Helvetica", Font.BOLD, 30));
    }

    public static void setupTextAreaAbout(){
        AboutService.textArea.setFont(new Font("Helvetica", Font.PLAIN, 18));
        AboutService.scroll.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }

    public static void setupButtonOkFontAbout(){
        AboutService.buttonOk.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public void addComponentsToContainer() {
        container.add(AboutService.titleLabel);
        container.add(AboutService.scroll);
        container.add(AboutService.buttonOk);
    }

    private void addActionListeners() {
        AboutService.buttonOk.addActionListener(AboutService.buttonHandler);
    }
}
