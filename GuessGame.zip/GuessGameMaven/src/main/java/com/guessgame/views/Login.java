package com.guessgame.views;

import com.guessgame.controllers.LoginController;
import com.guessgame.services.AuthService;
import com.guessgame.services.IconService;
import com.guessgame.services.LoginService;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Login extends JFrame {
    private Container container = getContentPane();

    public Login() {
        this.getContentPane().setBackground(new Color(0, 128, 0));
        setWindowIcon();
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionListeners();
        addItemListeners();
    }

    private void setLayoutManager() {
        container.setLayout(null);
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLocationAndSize() {
        LoginService.titleLabel.setBounds(50, 30, 150, 50);
        LoginService.emailLabel.setBounds(50, 150, 100, 30);
        LoginService.passwordLabel.setBounds(50, 220, 100, 30);
        LoginService.emailField.setBounds(150, 150, 150, 30);
        LoginService.passwordField.setBounds(150, 220, 150, 30);
        LoginService.showPassword.setBounds(150, 250, 150, 30);
        LoginService.loginButton.setBounds(50, 330, 80, 30);
        LoginService.createAccountLabel.setBounds(140, 520, 150, 30);
        LoginService.forgotPasswordLabel.setBounds(140, 380, 150, 30);
        LoginService.registerButton.setBounds(200, 330, 80, 30);
    }

    public static void setupTitleLabel(){
        LoginService.titleLabel.setFont(new Font("Helvetica", Font.BOLD, 30));
    }

    public static void setupEmailLabel(){
        LoginService.emailLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupPasswordLabel(){
        LoginService.passwordLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupForgotPasswordLabel(){
        LoginService.forgotPasswordLabel.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupCreateAccountLabel(){
        LoginService.createAccountLabel.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupEmailField(){
        LoginService.emailField.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupPasswordField(){
        LoginService.passwordField.setFont(new Font("Helvetica", Font.PLAIN, 10));
    }

    public static void setupLoginButtonLabel(){
        LoginService.loginButton.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupCancelButtonLabel(){
        LoginService.registerButton.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    private void addComponentsToContainer() {
        container.add(LoginService.titleLabel);
        container.add(LoginService.emailLabel);
        container.add(LoginService.passwordLabel);
        container.add(LoginService.emailField);
        container.add(LoginService.passwordField);
        container.add(LoginService.showPassword);
        container.add(LoginService.loginButton);
        container.add(LoginService.registerButton);
        container.add(LoginService.createAccountLabel);
        container.add(LoginService.forgotPasswordLabel);
    }

    private void addActionListeners() {
        LoginService.loginButton.addActionListener(AuthService.buttonHandler);
        LoginService.registerButton.addActionListener(AuthService.buttonHandler);
        LoginService.createAccountLabel.addMouseListener(AuthService.labelHandler);
        LoginService.forgotPasswordLabel.addMouseListener(LoginService.labelHandler);
    }

    private void addItemListeners() {
        LoginService.showPassword.addItemListener(AuthService.itemHandler);
    }
}
