package com.guessgame.views;

import com.guessgame.controllers.LoginController;
import com.guessgame.services.ForgotPasswordService;
import com.guessgame.services.IconService;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class ForgotPassword extends JFrame {
    private Container container = getContentPane();

    public ForgotPassword() {
        setWindowIcon();
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionListeners();
        this.getContentPane().setBackground(new Color(0, 128, 0));
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLayoutManager() {
        container.setLayout(null);
    }

    private void setLocationAndSize() {
        ForgotPasswordService.titleLabel.setBounds(30, 20, 180, 50);
        ForgotPasswordService.emailLabel.setBounds(30, 170, 100, 30);
        ForgotPasswordService.emailTextField.setBounds(140, 170, 150, 30);
        ForgotPasswordService.confirmButton.setBounds(180, 310, 70, 30);
    }

    public static void setupForgotPasswordTitleLabel(){
        ForgotPasswordService.titleLabel.setFont(new Font("Helvetica", Font.BOLD, 20));
    }

    public static void setupForgotPasswordEmailLabel(){
        ForgotPasswordService.emailLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupForgotPasswordEmailField(){
        ForgotPasswordService.emailTextField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    private void addComponentsToContainer() {
        container.add(ForgotPasswordService.titleLabel);
        container.add(ForgotPasswordService.emailLabel);
        container.add(ForgotPasswordService.emailTextField);
        container.add(ForgotPasswordService.confirmButton);
    }

    private void addActionListeners() {
        ForgotPasswordService.confirmButton.addActionListener(ForgotPasswordService.buttonHandler);
    }
}
