package com.guessgame.views;

import com.guessgame.controllers.LoginController;
import com.guessgame.services.AvatarService;
import com.guessgame.services.IconService;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Avatar extends JFrame {
    private Container container = getContentPane();

    public Avatar() {
        setWindowIcon();
        setLayoutManager();
        setLocationAndSize();
        addComponentsToContainer();
        addActionListeners();
        getContentPane().setBackground(new Color(0, 128, 0));
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLayoutManager() {
        container.setLayout(null);
    }

    private void setLocationAndSize() {
        AvatarService.titleLabel.setBounds(50, 20, 200, 50);
        AvatarService.avatarNameLabel.setBounds(50, 160, 100, 30);
        AvatarService.avatarNameField.setBounds(155, 160, 150, 30);
        AvatarService.confirmButton.setBounds(180, 300, 70, 30);
    }

    public static void setupTitleLabelAvatar(){
        AvatarService.titleLabel.setFont(new Font("Helvetica", Font.BOLD, 30));
    }

    public static void setupAvatarNameLabel(){
        AvatarService.avatarNameLabel.setFont(new Font("Helvetica", Font.PLAIN, 16));
    }

    public static void setupAvatarNameField(){
        AvatarService.avatarNameField.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public static void setupAvatarConfirmButton(){
        AvatarService.confirmButton.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    private void addComponentsToContainer() {
        container.add(AvatarService.titleLabel);
        container.add(AvatarService.avatarNameLabel);
        container.add(AvatarService.avatarNameField);
        container.add(AvatarService.confirmButton);
    }

    private void addActionListeners() {
        AvatarService.confirmButton.addActionListener(AvatarService.buttonHandler);
    }
}
