package com.guessgame.views;

import com.guessgame.controllers.LoginController;
import com.guessgame.services.IconService;
import com.guessgame.services.RulesService;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Rules extends JFrame {

    Container container = getContentPane();

    public Rules(){
        setWindowIcon();
        addActionListeners();
        setLayoutManager();
        addComponentsToContainer();
        setLocationAndSize();
        getContentPane().setBackground(new Color(0, 128, 0));
    }

    private void setLayoutManager(){
        container.setLayout(null);
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLocationAndSize(){
        RulesService.titleLabel.setBounds(50, 15, 200, 50);
        RulesService.scroll.setBounds(25, 75, 695, 500);
        RulesService.buttonOk.setBounds(320, 600, 70, 30);
    }

    public static void setupTitleLabelRules(){
        RulesService.titleLabel.setFont(new Font("Helvetica", Font.BOLD, 30));
    }

    public static void setupTextAreaRules(){
        RulesService.textArea.setFont(new Font("Helvetica", Font.PLAIN, 18));
        RulesService.scroll.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
    }

    public static void setupButtonOkFontRules(){
        RulesService.buttonOk.setFont(new Font("Helvetica", Font.PLAIN, 14));
    }

    public void addComponentsToContainer(){
        container.add(RulesService.titleLabel);
        container.add(RulesService.scroll);
        container.add(RulesService.buttonOk);
    }

    private void addActionListeners(){
        RulesService.buttonOk.addActionListener(RulesService.buttonHandler);
    }
}
