package com.guessgame.views;

import com.guessgame.controllers.GameController;
import com.guessgame.controllers.LoginController;
import com.guessgame.services.IconService;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Game extends JFrame {
    public Game() {
        setWindowIcon();
        initialiseComponents();
        getContentPane().setBackground(new Color(0, 128, 0));
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initialiseComponents() {
        JPanel windowContent = new JPanel();
        JPanel parentIntermediaryPanel = new JPanel();

        BorderLayout borderLayout = new BorderLayout();
        windowContent.setLayout(borderLayout);
        windowContent.setBackground(new Color(0, 128, 0));
        windowContent.add("South", GameController.setupQuestionNumberPanel());
        getContentPane().add(windowContent, BorderLayout.AFTER_LINE_ENDS);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        getContentPane().add(GameController.setupHiddenVerticallyCenteredLabel(), java.awt.BorderLayout.PAGE_END);

        parentIntermediaryPanel.setBackground(new Color(0, 128, 0));
        parentIntermediaryPanel.setOpaque(false);
        parentIntermediaryPanel.setLayout(new BorderLayout());
        parentIntermediaryPanel.add(GameController.setupIntermediaryPanel(), BorderLayout.LINE_START);
        parentIntermediaryPanel.add(GameController.setupCenterPanel(), BorderLayout.CENTER);
        parentIntermediaryPanel.add(GameController.setupTimerPanel(), BorderLayout.PAGE_START);
        getContentPane().add(GameController.setupToolbarPanel(), BorderLayout.PAGE_START);
        getContentPane().add(parentIntermediaryPanel, BorderLayout.CENTER);

        GameController.disablePrimaryButtons();
        pack();
    }
}