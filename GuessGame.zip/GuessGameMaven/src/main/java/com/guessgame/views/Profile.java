package com.guessgame.views;

import com.guessgame.controllers.GameController;
import com.guessgame.controllers.LoginController;
import com.guessgame.controllers.ProfileController;
import com.guessgame.models.UserProfile;
import com.guessgame.services.IconService;
import com.guessgame.services.ProfileService;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.Objects;

public class Profile extends JFrame {
    private Container container = getContentPane();

    public Profile() {
        setWindowIcon();
        this.getContentPane().setBackground(new Color(0, 128, 0));
        setLayoutManager();
        setDesign();
        setLocationAndSize();
        addComponentsToContainer();
        addActionListeners();
    }

    public static void setupTitleLabel() {
        ProfileService.titleLabel.setFont(new Font("Helvetica", Font.BOLD, 30));
    }

    public static void setupFirstNameLabel() {
        ProfileService.firstNameLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupLastNameLabel() {
        ProfileService.lastNameLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupUsernameLabel() {
        ProfileService.usernameLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupEmailLabel() {
        ProfileService.emailLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupPhoneLabel() {
        ProfileService.telephoneLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupPasswordLabel() {
        ProfileService.passwordLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupDobLabel() {
        ProfileService.dobLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupGenderLabel() {
        ProfileService.genderLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupLocationLabel() {
        ProfileService.locationLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupPhotoLabel() {
        ProfileService.photoLabel.setFont(new Font("Helvetica", Font.PLAIN, 12));
    }

    public static void setupFirstNameField() {
        ProfileService.firstNameField.setEditable(false);
        ProfileController.onEditFirstNameButtonClick();
    }

    public static void setupLastNameField() {
        ProfileService.lastNameField.setEditable(false);
        ProfileController.onEditLastNameButtonClick();
    }

    public static void setupUsernameField() {
        ProfileService.usernameField.setEditable(false);
        ProfileController.onEditUsernameButtonClick();
    }

    public static void setupPasswordField() {
        ProfileService.passwordField.setEditable(false);
        ProfileController.onEditPasswordButtonClick();
    }

    public static void setupEmailField() {
        ProfileService.emailField.setEditable(false);
        ProfileController.onEditEmailButtonClick();
    }

    public static void setupPhoneField() {
        ProfileService.telephoneField.setEditable(false);
        ProfileController.onEditPhoneButtonClick();
    }

    public static void setupDobField() {
        ProfileService.dobField.setEditable(false);
        ProfileController.onEditDobButtonClick();
    }

    public static void setupLocationField() {
        ProfileService.locationField.setEditable(false);
        ProfileController.onEditLocationButtonClick();
    }

    private void setWindowIcon() {
        try {
            setIconImage(IconService.setWindowIcon(LoginController.class, "dragon-Welsh.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setLayoutManager() {
        container.setLayout(null);
    }

    private void setDesign() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            SwingUtilities.updateComponentTreeUI(Profile.this);
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }
    }

    private void setLocationAndSize() {
        ProfileService.titleLabel.setBounds(50, 15, 200, 50);

        ProfileService.firstNameLabel.setBounds(50, 110, 160, 30);
        ProfileService.firstNameField.setBounds(120, 110, 200, 32);

        ProfileService.lastNameLabel.setBounds(50, 160, 130, 40);
        ProfileService.lastNameField.setBounds(120, 160, 200, 32);

        ProfileService.emailLabel.setBounds(50, 210, 120, 30);
        ProfileService.emailField.setBounds(120, 210, 200, 32);

        ProfileService.usernameLabel.setBounds(50, 260, 100, 30);
        ProfileService.usernameField.setBounds(120, 260, 200, 32);

        ProfileService.passwordLabel.setBounds(50, 360, 100, 30);
        ProfileService.passwordField.setBounds(120, 360, 200, 32);

        ProfileService.telephoneLabel.setBounds(50, 310, 120, 30);
        ProfileService.telephoneField.setBounds(120, 310, 200, 32);

        ProfileService.dobLabel.setBounds(50, 410, 120, 30);
        ProfileService.dobField.setBounds(120, 410, 200, 32);

        ProfileService.genderLabel.setBounds(50, 460, 120, 30);
        ProfileService.genderField.setBounds(120, 460, 200, 32);

        ProfileService.locationScrollPane.setBounds(500, 110, 200, 200);
        ProfileService.locationLabel.setBounds(440, 110, 150, 30);

        ProfileService.editLocationButton.setBounds(560, 330, 70, 30);
        ProfileService.editFNButton.setBounds(340, 110, 70, 30);
        ProfileService.editLNButton.setBounds(340, 160, 70, 30);
        ProfileService.editEmailButton.setBounds(340, 210, 70, 30);
        ProfileService.editUsernameButton.setBounds(340, 260, 70, 30);
        ProfileService.editPhoneButton.setBounds(340, 310, 70, 30);
        ProfileService.editPasswordButton.setBounds(340, 360, 70, 30);
        ProfileService.editDobButton.setBounds(340, 410, 70, 30);
        ProfileService.editGenderButton.setBounds(340, 460, 70, 30);

        ProfileService.uploadButton.setBounds(800, 330, 70, 30);
        ProfileService.deleteButton.setBounds(920, 330, 70, 30);
        ProfileService.deleteAccountButton.setBounds(800, 400, 140, 30);
        ProfileService.downloadAccountButton.setBounds(800, 450, 140, 30);

        try {
            UserProfile.profile = ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("profile.jpg")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        ProfileService.photo = new JLabel(new ImageIcon(Objects.requireNonNull(UserProfile.profile)));

        ProfileService.photoLabel.setBounds(760, 110, 100, 30);
        ProfileService.photo.setBounds(800, 110, 200, 200);

        ProfileService.saveButton.setBounds(50, 550, 80, 30);
        ProfileService.cancelButton.setBounds(250, 550, 80, 30);
    }

    private void addComponentsToContainer() {
        container.add(ProfileService.titleLabel);

        container.add(ProfileService.firstNameField);
        container.add(ProfileService.firstNameLabel);

        container.add(ProfileService.lastNameField);
        container.add(ProfileService.lastNameLabel);

        container.add(ProfileService.usernameLabel);
        container.add(ProfileService.usernameField);

        container.add(ProfileService.passwordLabel);
        container.add(ProfileService.passwordField);

        container.add(ProfileService.emailLabel);
        container.add(ProfileService.emailField);

        container.add(ProfileService.telephoneLabel);
        container.add(ProfileService.telephoneField);

        container.add(ProfileService.dobField);
        container.add(ProfileService.dobLabel);

        container.add(ProfileService.genderField);
        container.add(ProfileService.genderLabel);

        container.add(ProfileService.locationScrollPane);
        container.add(ProfileService.locationLabel);

        container.add(ProfileService.photoLabel);
        container.add(ProfileService.photo);

        container.add(ProfileService.saveButton);
        container.add(ProfileService.cancelButton);
        container.add(ProfileService.editFNButton);
        container.add(ProfileService.editLNButton);
        container.add(ProfileService.editEmailButton);
        container.add(ProfileService.editUsernameButton);
        container.add(ProfileService.editPhoneButton);
        container.add(ProfileService.editPasswordButton);
        container.add(ProfileService.editDobButton);
        container.add(ProfileService.editGenderButton);
        container.add(ProfileService.editLocationButton);
        container.add(ProfileService.uploadButton);
        container.add(ProfileService.deleteButton);
        container.add(ProfileService.deleteAccountButton);
        container.add(ProfileService.downloadAccountButton);
    }

    private void addActionListeners() {
        ProfileService.saveButton.addActionListener(ProfileService.buttonHandler);
        ProfileService.uploadButton.addActionListener(ProfileService.buttonHandler);
        ProfileService.cancelButton.addActionListener(ProfileService.buttonHandler);
        ProfileService.deleteButton.addActionListener(ProfileService.buttonHandler);
        ProfileService.deleteAccountButton.addActionListener(ProfileService.buttonHandler);
        ProfileService.downloadAccountButton.addActionListener(ProfileService.buttonHandler);
    }
}
