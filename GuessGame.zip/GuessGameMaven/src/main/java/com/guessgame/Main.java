package com.guessgame;

import com.guessgame.controllers.QuestionController;
import com.guessgame.services.FirebaseService;
import com.guessgame.services.LoginService;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        FirebaseService firebaseService = new FirebaseService();
        firebaseService.initialSetup();
        QuestionController.getQuestions();
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        LoginService.openWindow();
    }
}
