package com.guessgame.models;

public class QuestionResponse {
    private Integer questionId;
    private Integer status;

    public QuestionResponse(Integer questionId, Integer status) {
        this.questionId = questionId;
        this.status = status;
    }

    public Integer getQuestionId() {
        return questionId;
    }

    public Integer getStatus() {
        return status;
    }
}
