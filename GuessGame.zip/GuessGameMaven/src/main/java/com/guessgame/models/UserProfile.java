package com.guessgame.models;

import java.awt.image.BufferedImage;

public class UserProfile {
    public static BufferedImage profile;
}
