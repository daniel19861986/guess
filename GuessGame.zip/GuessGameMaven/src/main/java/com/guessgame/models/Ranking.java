package com.guessgame.models;
public class Ranking {
    String gameSessionid;
    String name;
    int score;

    public Ranking(String gameSessionid, String name, int score) {
        this.gameSessionid = gameSessionid;
        this.name = name;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public int getScore() {
        return score;
    }
}
