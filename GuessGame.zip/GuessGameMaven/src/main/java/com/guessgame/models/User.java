package com.guessgame.models;

public class User {
    public String firstName;
    public String lastName;
    public String email;
    public String username;
    public String telephone;
    public String dateOfBirth;
    public Integer gender;
    public String location;

    public User(String firstName, String lastName, String email, String username, String telephone, String dateOfBirth, Integer gender, String location) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.username = username;
        this.telephone = telephone;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.location = location;
    }
}
