package com.guessgame.services;

import com.google.api.core.ApiFuture;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.gson.Gson;
import com.guessgame.models.Question;
import com.guessgame.models.User;
import com.guessgame.models.AuthResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.ExecutionException;

public class FirebaseService {
    public static Firestore db;
    private static String firebaseKey = "AIzaSyBClo5JUrEhamqHEPReuMkiuqkoYKQ2CE4";
    private static Logger logger = LoggerFactory.getLogger(FirebaseService.class);

    public static AuthResponse register(String email, String password) {
        HttpPost post = new HttpPost(String.format("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=%s", firebaseKey));
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("email", email));
        urlParameters.add(new BasicNameValuePair("password", password));
        try {
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse response = httpClient.execute(post)) {
            Gson gson = new Gson();
            AuthResponse userInfo;
            userInfo = gson.fromJson(EntityUtils.toString(response.getEntity()), AuthResponse.class);
            if (userInfo.getEmail() == null) {
                return null;
            } else {
                return userInfo;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static AuthResponse login(String email, String password) {
        HttpPost post = new HttpPost(String.format("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=%s", firebaseKey));
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("email", email));
        urlParameters.add(new BasicNameValuePair("password", password));
        try {
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse response = httpClient.execute(post)) {
            Gson gson = new Gson();
            AuthResponse userInfo;
            userInfo = gson.fromJson(EntityUtils.toString(response.getEntity()), AuthResponse.class);
            if (userInfo.getEmail() == null) {
                return null;
            } else {
                return userInfo;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void createDocumentWithCustomUidAndObjectHashmap(String collectionName, String uid, Map<String, Object> data) {
        try {
            ApiFuture<WriteResult> docRef = db.collection(collectionName).document(uid).set(data);
            logger.debug(String.format("Added document at: %s", docRef.get().getUpdateTime()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void createDocumentWithCustomUidAndStringHashmap(String collectionName, String uid, Map<String, String> data) {
        try {
            ApiFuture<WriteResult> docRef = db.collection(collectionName).document(uid).set(data);
            logger.debug(String.format("Added document at: %s", docRef.get().getUpdateTime()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unused")
    public static Map<String, Object> getDocumentAsMap(String collectionName, String documentName) {
        DocumentReference docRef = db.collection(collectionName).document(documentName);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        try {
            DocumentSnapshot documentSnapshot = future.get();
            if (documentSnapshot.exists()) {
                return documentSnapshot.getData();
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static User getDocumentAsEntity(String collectionName, String documentName) {
        DocumentReference docRef = db.collection(collectionName).document(documentName);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        User user = new User(null, null, null, null, null, null, 0, null);
        try {
            DocumentSnapshot documentSnapshot = future.get();
            if (documentSnapshot.exists()) {
                if (documentSnapshot.contains("firstName")) {
                    user.firstName = Objects.requireNonNull(documentSnapshot.get("firstName")).toString();
                }
                if (documentSnapshot.contains("lastName")) {
                    user.lastName = Objects.requireNonNull(documentSnapshot.get("lastName")).toString();
                }
                if (documentSnapshot.contains("email")) {
                    user.email = Objects.requireNonNull(documentSnapshot.get("email")).toString();
                }
                if (documentSnapshot.contains("username")) {
                    user.username = Objects.requireNonNull(documentSnapshot.get("username")).toString();
                }
                if (documentSnapshot.contains("telephone")) {
                    user.telephone = Objects.requireNonNull(documentSnapshot.get("telephone")).toString();
                }
                if (documentSnapshot.contains("dateOfBirth")) {
                    user.dateOfBirth = Objects.requireNonNull(documentSnapshot.get("dateOfBirth")).toString();
                }
                if (documentSnapshot.contains("gender")) {
                    if (documentSnapshot.get("gender") != null) {
                        if (Objects.requireNonNull(documentSnapshot.get("gender")).toString().equals("Male")) {
                            user.gender = 0;
                        } else {
                            user.gender = 1;
                        }
                    }
                }
                if (documentSnapshot.contains("location")) {
                    user.location = Objects.requireNonNull(documentSnapshot.get("location")).toString();
                }
                return user;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return null;
    }

    public static List<Question> getQuestionDocumentsAsEntity(String collectionName, String documentName) {
        List<Question> questions = new ArrayList<>();
        DocumentReference docRef = db.collection(collectionName).document(documentName);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        try {
            DocumentSnapshot documentSnapshot = future.get();
            if (documentSnapshot.exists()) {
                List<?> questionList = (List<?>) Objects.requireNonNull(documentSnapshot.get("questions"));
                for (Object questionObject : questionList) {
                    HashMap<?, ?> questionHashmap = (HashMap<?, ?>) questionObject;
                    Long questionId = (Long) questionHashmap.get("id");
                    Question question = new Question(
                            questionId.intValue(),
                            (String) questionHashmap.get("question"),
                            (String) questionHashmap.get("answer")
                    );
                    questions.add(question);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return questions;
    }

    @SuppressWarnings("unused")
    public static List<String> searchDocument(String collectionName, String field, String value) {
        List<String> results = new ArrayList<>();
        try {
            CollectionReference collectionRef = db.collection(collectionName);
            Query query = collectionRef.whereEqualTo(field, value);
            ApiFuture<QuerySnapshot> querySnapshot = query.get();
            for (DocumentSnapshot document : querySnapshot.get().getDocuments()) {
                results.add(document.getString("name"));
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return results;
    }

    public static void deleteAccount() {
        HttpPost post = new HttpPost(String.format("https://identitytoolkit.googleapis.com/v1/accounts:delete?key=%s", firebaseKey));
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("idToken", UserService.idToken));
        try {
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse ignored = httpClient.execute(post)) {
            FirebaseService.deleteDocument("users", UserService.localId);
            ProfileService.closeWindow();
            GameService.closeWindow();
            LoginService.openWindow();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void deleteDocument(String collectionName, String documentId) {
        try {
            ApiFuture<WriteResult> docRef = db.collection(collectionName).document(documentId).delete();
            logger.debug(String.format("Deleted document ID %s at %s", documentId, docRef.get().getUpdateTime()));
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    public static void resetAccountPassword() {
        HttpPost post = new HttpPost(String.format("https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=%s", firebaseKey));
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("requestType", "PASSWORD_RESET"));
        urlParameters.add(new BasicNameValuePair("email", ForgotPasswordService.emailTextField.getText()));
        try {
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse ignored = httpClient.execute(post)) {
            ForgotPasswordService.closeWindow();
            JOptionPane.showMessageDialog(null, "Please check your email for password reset instructions. If you cannot find it in your inbox, please check your junk mail.");
            LoginService.openWindow();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void changeAccountPassword() {
        HttpPost post = new HttpPost(String.format("https://identitytoolkit.googleapis.com/v1/accounts:update?key=%s", firebaseKey));
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("idToken", UserService.idToken));
        urlParameters.add(new BasicNameValuePair("password", String.valueOf(ProfileService.passwordField.getPassword())));
        urlParameters.add(new BasicNameValuePair("returnSecureToken", "false"));
        try {
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse ignored = httpClient.execute(post)) {
            JOptionPane.showMessageDialog(null, "Your account password has been reset.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void changeAccountEmail() {
        HttpPost post = new HttpPost(String.format("https://identitytoolkit.googleapis.com/v1/accounts:update?key=%s", firebaseKey));
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("idToken", UserService.idToken));
        urlParameters.add(new BasicNameValuePair("email", String.valueOf(ProfileService.emailField.getText())));
        urlParameters.add(new BasicNameValuePair("returnSecureToken", "false"));
        try {
            post.setEntity(new UrlEncodedFormEntity(urlParameters));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); CloseableHttpResponse ignored = httpClient.execute(post)) {
            JOptionPane.showMessageDialog(null, "Your account email has been updated.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void initialSetup() {
        try {
            InputStream inputStream = getClass()
                    .getClassLoader().getResourceAsStream("key.json");
            FirestoreOptions firestoreOptions;
            if (inputStream != null) {
                firestoreOptions = FirestoreOptions.getDefaultInstance().toBuilder()
                        .setCredentials(GoogleCredentials.fromStream(inputStream))
                        .setProjectId("guessgame-api")
                        .build();
                db = firestoreOptions.getService();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

        try {
            InputStream inputStream = getClass()
                    .getClassLoader().getResourceAsStream("key.json");
            FirebaseOptions options;
            if (inputStream != null) {
                options = new FirebaseOptions.Builder()
                        .setCredentials(GoogleCredentials.fromStream(inputStream))
                        .setDatabaseUrl("https://adsoma-api.firebaseio.com")
                        .build();
                FirebaseApp.initializeApp(options);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}

//    public static FirebaseAuth getInstance() {
//        return FirebaseAuth.getInstance(FirebaseApp.getInstance());
//    }

//    public void createDocument(String collectionName, Map<String, Object> data) {
//        try {
//            ApiFuture<DocumentReference> docRef = db.collection(collectionName).add(data);
//            logger.debug(String.format("Added document with ID: %s", docRef.get().getId()));
//        } catch (InterruptedException | ExecutionException e) {
//            e.printStackTrace();
//        }
//    }

//    public void updateDocument(String collectionName, String documentId, Map<String, Object> data) {
//        try {
//            ApiFuture<WriteResult> docRef = db.collection(collectionName).document(documentId).update(data);
//            logger.debug(String.format("Updated document ID %s at %s", documentId, docRef.get().getUpdateTime()));
//        } catch (InterruptedException | ExecutionException e) {
//            e.printStackTrace();
//        }
//    }