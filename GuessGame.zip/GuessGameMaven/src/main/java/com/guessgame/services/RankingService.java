package com.guessgame.services;

import com.guessgame.controllers.ProfileController;
import com.guessgame.controllers.RankingController;
import com.guessgame.views.Ranking;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class RankingService {
    public static List<String> rankingTableColumns = new ArrayList<>();
    public static List<com.guessgame.models.Ranking> rankingList = new ArrayList<>();
    public static JButton buttonOk = new JButton(String.valueOf(RankingText.OK));
    public static TableModel rankingTableModel;
    public static JTable rankingTable;

    public static ButtonHandler buttonHandler = new ButtonHandler();

    private static Ranking ranking = new Ranking();

    public static void openWindow() {
        ranking = new Ranking();
        ranking.setTitle("Ranking");
        ranking.setVisible(true);
        ranking.setBounds(10, 10, 370, 600);
        ranking.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ranking.setResizable(false);
    }

    public static void closeWindow() {
        ranking.dispose();
    }

    public enum RankingText{
        OK("Ok");

        private String rankingText;

        RankingText(String rankingText){
            this.rankingText = rankingText;
        }

        @Override
        public String toString(){
            return rankingText;
        }
    }

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event){
            String cmd = event.getActionCommand();
            RankingController.performButtonHandlerAction(cmd);
        }
    }
}
