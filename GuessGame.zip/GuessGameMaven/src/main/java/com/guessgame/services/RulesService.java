package com.guessgame.services;

import com.guessgame.controllers.RulesController;
import com.guessgame.views.Rules;

import javax.swing.*;
import java.awt.event.ActionListener;

public class RulesService {
    public static JLabel titleLabel = new JLabel(String.valueOf(RulesText.TITLE));
    public static JTextArea textArea = new JTextArea(50, 50);
    public static JScrollPane scroll = new JScrollPane(textArea);
    public static JButton buttonOk = new JButton(String.valueOf(RulesText.OK));

    public static ButtonHandler buttonHandler = new ButtonHandler();

    private static Rules rules = new Rules();

    public static void openWindow() {
        rules.setTitle("Rules");
        rules.setVisible(true);
        rules.setBounds(10, 10, 750, 700);
        rules.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        rules.setResizable(false);
        rules.setupTitleLabelRules();
        rules.setupTextAreaRules();
        rules.setupButtonOkFontRules();
    }

    public static void closeWindow(){
        rules.dispose();
    }

    public enum RulesText{
        TITLE("Rules"),
        OK("Ok");

        private String rulesText;

        RulesText(String rulesText){
            this.rulesText = rulesText;
        }

        @Override
        public String toString(){
            return rulesText;
        }
    }

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent event){
            String cmd = event.getActionCommand();
            try{
                RulesController.performButtonHandlerAction(cmd);
            }
            catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }
}

