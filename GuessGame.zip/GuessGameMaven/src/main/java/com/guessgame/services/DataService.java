package com.guessgame.services;

import com.guessgame.models.QuestionResponse;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DataService {
    public static List<Map<String, Integer>> responses = new ArrayList<>();
    public static List<QuestionResponse> questionResponses = new ArrayList<>();

    public static void setQuestionAsAnswered(int status, int questionId) {
        Map<String, Integer> response = new HashMap<>();
        response.put("status", status);
        response.put("questionId", questionId);
        responses.add(response);
        responses = responses.stream().distinct().collect(Collectors.toList());
        questionResponses.add(new QuestionResponse(questionId, status));
    }

    public static boolean getQuestionAnswerStatus(int questionId) {
        boolean questionAnswered = false;
        for (QuestionResponse questionResponse : questionResponses) {
            if (questionResponse.getQuestionId() == questionId) {
                if (questionResponse.getStatus() == 1 || questionResponse.getStatus() == 2) {
                    questionAnswered = true;
                }
            }
        }
        return questionAnswered;
    }

    public static void setScore() {
        Map<String, Object> data = new HashMap<>();
        data.put("uid", UserService.localId);
        data.put("name", UserService.user.firstName);
        data.put("responses", responses);
        data.put("score", ScoreService.score);
        FirebaseService.createDocumentWithCustomUidAndObjectHashmap("gameSessions", GameService.gameSessionId, data);
    }

    public static void setProfile() {
        Map<String, String> profileData = new HashMap<>();
        profileData.put("firstName", UserService.user.firstName);
        profileData.put("lastName", UserService.user.lastName);
        profileData.put("email", UserService.user.email);
        profileData.put("dateOfBirth", UserService.user.dateOfBirth);
        profileData.put("location", UserService.user.location);
        profileData.put("gender", String.valueOf(UserService.user.gender));
        profileData.put("username", String.valueOf(UserService.user.username));
        profileData.put("telephone", String.valueOf(UserService.user.telephone));
        JOptionPane.showMessageDialog(null, "Your account has been updated.");
        FirebaseService.createDocumentWithCustomUidAndStringHashmap("users", UserService.localId, profileData);
    }
}