package com.guessgame.services;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.IOException;
import java.util.Objects;

public class IconService {
    public static Image setWindowIcon(Class<?> controllerClass) throws IOException {
        return ImageIO.read(Objects.requireNonNull(controllerClass.getClassLoader().getResource("ranking.png"))).getScaledInstance(20, 20, Image.SCALE_DEFAULT);
    }

    public static Image setWindowIcon(Class<?> controllerClass, String imageName) throws IOException {
        return ImageIO.read(Objects.requireNonNull(controllerClass.getClassLoader().getResource(imageName))).getScaledInstance(20, 20, Image.SCALE_DEFAULT);
    }
}

