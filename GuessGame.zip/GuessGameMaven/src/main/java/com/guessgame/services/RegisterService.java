package com.guessgame.services;

import com.guessgame.views.Register;

import javax.swing.*;
import java.awt.*;

public class RegisterService {
    public static JLabel titleLabel = new JLabel(String.valueOf(RegisterText.TITLE));
    public static JLabel usernameLabel = new JLabel(String.valueOf(RegisterText.USERNAME));
    public static JLabel passwordLabel = new JLabel(String.valueOf(RegisterText.PASSWORD));
    public static JLabel firstNameLabel = new JLabel(String.valueOf(RegisterText.FIRSTNAME));
    public static JLabel lastNameLabel = new JLabel(String.valueOf(RegisterText.LASTNAME));
    public static JLabel emailLabel = new JLabel(String.valueOf(RegisterText.EMAIL));
    public static JLabel telephoneLabel = new JLabel(String.valueOf(RegisterText.TELEPHONE));
    public static JLabel dobLabel = new JLabel(String.valueOf(RegisterText.DOB));
    public static JLabel genderLabel = new JLabel(String.valueOf(RegisterText.GENDER));
    public static JLabel locationLabel = new JLabel(String.valueOf(RegisterText.LOCATION));
    public static JTextField usernameField = new JTextField();
    public static JPasswordField passwordField = new JPasswordField();
    public static JTextField firstNameField = new JTextField();
    public static JTextField lastNameField = new JTextField();
    public static JTextField emailField = new JTextField();
    public static JTextField telephoneField = new JTextField();
    public static JTextField dobField = new JTextField();
    public static JComboBox<String> genderField = new JComboBox<>(new String[]{"Male", "Female"});
    public static JTextArea locationField = new JTextArea();
    public static JScrollPane locationScrollPane = new JScrollPane(locationField);
    public static JButton signUpButton = new JButton(String.valueOf(RegisterText.SIGNUP));
    public static JButton cancelButton = new JButton(String.valueOf(RegisterText.CANCEL));
    public static JLabel goLogin = new JLabel(String.valueOf(RegisterText.GO_LOGIN));
    private static Register register = new Register();

    public static void openWindow() {
        register.setTitle("Register");
        register.setVisible(true);
        register.setBounds(10, 10, 750, 700);
        register.setBackground(new Color(0, 128, 0));
        register.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        register.setResizable(false);
        Register.setupRegisterTitleLabel();
        Register.setupRegisterFirstNameLabel();
        Register.setupRegisterLastNameLabel();
        Register.setupRegisterUsernameLabel();
        Register.setupRegisterEmailLabel();
        Register.setupTelephoneLabel();
        Register.setupPasswordLabel();
        Register.setupDOBLabel();
        Register.setupGenderLabel();
        Register.setupLocationLabel();
        Register.setupGoLoginLabel();
        Register.setupFirstNameField();
        Register.setupLastNameField();
        Register.setupUsernameField();
        Register.setupEmailField();
        Register.setupPasswordField();
        Register.setupTelephoneField();
        Register.setupLocationField();
        Register.setupDOBField();
        Register.setupGenderField();
        Register.setupSignUpButtonLabel();
        Register.setupCancelButtonLabel();
    }

    public static void closeWindow() {
        register.dispose();
    }

    public enum RegisterText {
        TITLE("Registration"),
        USERNAME("Username: "),
        PASSWORD("Password: "),
        SIGNUP("Sign Up"),
        CANCEL("Cancel"),
        FIRSTNAME("First Name: "),
        LASTNAME("Last Name: "),
        EMAIL("Email Address: "),
        TELEPHONE("Telephone: "),
        DOB("Date of Birth: "),
        GENDER("Gender: "),
        LOCATION("Location: "),
        GO_LOGIN("Go to Login");

        private String registerText;

        RegisterText(String registerText) {
            this.registerText = registerText;
        }

        @Override
        public String toString() {
            return registerText;
        }
    }
}
