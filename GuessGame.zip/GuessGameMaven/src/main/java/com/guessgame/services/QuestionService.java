package com.guessgame.services;

import com.guessgame.models.Question;

import java.util.HashMap;

public class QuestionService {
    public static Question[] questionList = new Question[20];
    public static int questionIndex = -1;
    public static int MAX_QUESTION_SIZE = 20;
    public static int guessesMade = 0;
    public static int questionSize = QuestionService.MAX_QUESTION_SIZE + 1;
    public static HashMap<Integer, String> questionResponses = new HashMap<>();

    public static void setCurrentQuestionResponse(int questionNumber, String response) {
        questionResponses.put(questionNumber, response);
    }

    public static String getCurrentQuestionResponse(int questionNumber) {
        return questionResponses.get(questionNumber);
    }

    public static void setupCurrentQuestionResponses() {
        for (int i = 1; i < questionSize; i++) {
            questionResponses.put(i, null);
        }
    }
}
