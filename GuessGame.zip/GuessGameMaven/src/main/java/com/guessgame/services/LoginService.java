package com.guessgame.services;

import com.guessgame.controllers.LoginController;
import com.guessgame.views.Login;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class LoginService {
    public static JLabel emailLabel = new JLabel(String.valueOf(LoginText.EMAIL));
    public static JLabel titleLabel = new JLabel(String.valueOf(LoginText.TITLE));
    public static JLabel passwordLabel = new JLabel(String.valueOf(LoginText.PASSWORD));
    public static JTextField emailField = new JTextField();
    public static JPasswordField passwordField = new JPasswordField();
    public static JButton loginButton = new JButton(String.valueOf(LoginText.LOGIN));
    public static JButton registerButton = new JButton(String.valueOf(LoginText.REGISTER));
    public static JCheckBox showPassword = new JCheckBox(String.valueOf(LoginText.SHOW_PASSWORD));
    public static JLabel createAccountLabel = new JLabel(String.valueOf(LoginText.CREATE_ACCOUNT));
    public static JLabel forgotPasswordLabel = new JLabel(String.valueOf(LoginText.FORGOT_PASSWORD));
    public static LabelHandler labelHandler = new LabelHandler();
    private static Login login = new Login();

    public static void openWindow() {
        login.setTitle("Login");
        login.setVisible(true);
        login.setBounds(100, 10, 370, 600);
        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        login.setResizable(false);
        login.setupTitleLabel();
        login.setupEmailLabel();
        login.setupPasswordLabel();
        login.setupForgotPasswordLabel();
        login.setupCreateAccountLabel();
        login.setupEmailField();
        login.setupPasswordField();
        login.setupLoginButtonLabel();
        login.setupCancelButtonLabel();
    }

    public static void closeWindow() {
        login.dispose();
    }

    public enum LoginText {
        TITLE("Login"),
        EMAIL("Email:"),
        PASSWORD("Password:"),
        LOGIN("Login"),
        REGISTER("Cancel"),
        SHOW_PASSWORD("Show Password"),
        FORGOT_PASSWORD("Forgot Password"),
        CREATE_ACCOUNT("Create Account");

        private String loginText;

        LoginText(String loginText) {
            this.loginText = loginText;
        }

        @Override
        public String toString() {
            return loginText;
        }
    }

    public static class LabelHandler implements MouseListener {
        @Override
        public void mouseClicked(MouseEvent event) {
            LoginController.onForgotPasswordLabelClick();
        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {
        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {
        }

        @Override
        public void mouseEntered(MouseEvent event) {
        }

        @Override
        public void mouseExited(MouseEvent event) {
        }
    }
}