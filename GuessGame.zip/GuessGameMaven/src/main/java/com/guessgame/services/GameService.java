package com.guessgame.services;

import com.guessgame.controllers.GameController;
import com.guessgame.controllers.QuestionController;
import com.guessgame.views.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.sql.Timestamp;
import java.util.ArrayList;

public class GameService {
    public static String message;
    public static String answer;
    public static String alertMessage;
    public static JButton previousButton = new JButton(String.valueOf(GuiText.PREVIOUS));
    public static JButton resumeButton = new JButton(String.valueOf(GuiText.RESUME));
    public static JButton startButton = new JButton(String.valueOf(GuiText.START));
    public static JButton sendButton = new JButton(String.valueOf(GuiText.SEND));
    public static JButton pauseButton = new JButton(String.valueOf(GuiText.PAUSE));
    public static JButton quitButton = new JButton(String.valueOf(GuiText.QUIT));
    public static JButton submitButton = new JButton(String.valueOf(GuiText.SUBMIT));
    public static JButton nextButton = new JButton(String.valueOf(GuiText.NEXT));
    public static JTextArea textEntryArea = new JTextArea();
    public static JLabel timerLabel = new JLabel();
    public static JLabel scoreLabel = new JLabel();
    public static Timer gamePlayTimer;
    public static Timer gamePauseTimer;
    public static String guesses = "";
    public static boolean gameOver;
    public static int badGuesses = 0;
    public static int correctGuesses = 0;
    public static int pausesRemaining = 3;
    public static JPanel questionNumberPanel = new JPanel();
    public static JButton[] buttons = new JButton[21];
    public static JPanel timerPanel = new JPanel();
    public static JPanel alphanumericPanel = new JPanel();
    public static ArrayList<JButton> alphanumericButtons = new ArrayList<>();
    public static Display display = new Display();
    public static ButtonHandler buttonHandler = new ButtonHandler();
    public static JPanel buttonOptionsPanel = new JPanel();
    public static JPanel scoreboardPanel = new JPanel();
    public static JLabel hiddenVerticallyCenteredLabel = new JLabel();
    public static JPanel clusterPanel = new JPanel();
    public static JScrollPane scrollPane = new JScrollPane();
    public static JPanel textEntryPanel = new JPanel();
    public static JLabel questionLabel = new JLabel();
    public static JPanel mainPanel = new JPanel();
    public static JPanel intermediaryPanel = new JPanel();
    public static JPanel centerPanel = new JPanel();
    public static JToolBar toolbar = new JToolBar();
    public static JPanel toolbarPanel = new JPanel();
    public static String gameSessionId;
    public static String restartGameText;
    public static int gamePlayTime;
    public static JLabel photo = new JLabel();
    public static JLabel avatarName = new JLabel();
    private static Game game = new Game();

    public static void openWindow() {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        gameSessionId = String.valueOf(timestamp.getTime());
        game.setVisible(true);
    }

    public static void closeWindow() {
        game.dispose();
    }

    public enum GuiText {
        START("Start"),
        QUIT("Quit"),
        SUBMIT("Submit"),
        RESUME("Resume"),
        SEND("Send"),
        NEXT(">"),
        PREVIOUS("<"),
        PAUSE("Pause"),
        RANKING("Ranking"),
        NEW_GAME("New Game");

        private String guiText;

        GuiText(String guiText) {
            this.guiText = guiText;
        }

        @Override
        public String toString() {
            return guiText;
        }
    }

    public static class Display extends JPanel {
        Display() {
            setPreferredSize(new Dimension(550, 260));
            setBackground(new Color(255, 255, 255));
            setFont(new Font("Helvetica", Font.BOLD, 16));
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int width = super.getWidth();
            int height = super.getHeight();
            ((Graphics2D) g).setStroke(new BasicStroke(3));
            if (GameService.message != null) {
                g.setColor(Color.DARK_GRAY);
                g.drawString(GameService.message, 30, 50);
            }
            if (GameService.alertMessage != null) {
                g.setColor(Color.DARK_GRAY);
                g.drawString(GameService.alertMessage, 30, 100);
            }
            if (GameService.gameOver) {
                GameService.alertMessage = "Click on \"Next\" to play again.";
            } else {
                g.setColor(Color.DARK_GRAY);
                g.drawString("Chances:  " + (3 - GameService.badGuesses), width - 125, 50);
            }

            boolean questionAnswered = false;
            try {
                questionAnswered = QuestionController.checkIfQuestionAnswered();
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (QuestionService.questionIndex < QuestionService.MAX_QUESTION_SIZE) {
                if (GameService.answer != null && !questionAnswered) {
                    for (int i = 0; i < GameService.answer.length(); i++) {
                        if (String.valueOf(GameService.answer.charAt(i)).trim().length() > 0) {
                            int underlineYCoordinate = height - 50;
                            int letterYCoordinate = height - 70;
                            g.drawLine(30 + i * 20, underlineYCoordinate, 40 + i * 20, underlineYCoordinate);
                            if (GameService.guesses.indexOf(GameService.answer.charAt(i)) >= 0) {
                                g.drawString(String.valueOf(GameService.answer.charAt(i)), 30 + i * 20, letterYCoordinate);
                            }
                        }
                    }
                }
            }
        }
    }

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            String cmd = e.getActionCommand();
            GameController.performButtonHandlerAction(cmd);
            GameService.display.repaint();
        }
    }
}
