package com.guessgame.services;

import com.guessgame.controllers.AboutController;
import com.guessgame.views.About;

import javax.swing.*;
import java.awt.event.ActionListener;

public class AboutService {
    public static JButton buttonOk = new JButton(String.valueOf(AboutText.OK));
    public static JTextArea textArea = new JTextArea(50, 50);
    public static JScrollPane scroll = new JScrollPane(textArea);
    public static JLabel titleLabel = new JLabel(String.valueOf(AboutText.TITLE));

    public static ButtonHandler buttonHandler = new ButtonHandler();

    private static About aboutSoftware = new About();

    public static void openWindow(){
        aboutSoftware.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        aboutSoftware.setTitle("About");
        aboutSoftware.setVisible(true);
        aboutSoftware.setBounds(10, 10, 750, 700);
        aboutSoftware.setResizable(false);
        aboutSoftware.setupTitleLabelAbout();
        aboutSoftware.setupTextAreaAbout();
        aboutSoftware.setupButtonOkFontAbout();
    }

    public static void closeWindow(){
        aboutSoftware.dispose();
    }

    public enum AboutText{
        TITLE("About"),
        OK("Ok"),
        ABOUT("About Software");

        private String aboutSoftwareText;

        AboutText(String aboutSoftwareText){
            this.aboutSoftwareText = aboutSoftwareText;
        }

        @Override
        public String toString(){
            return aboutSoftwareText;
        }
    }

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent event){
            String cmd = event.getActionCommand();
            try{
                AboutController.performButtonHandlerAction(cmd);
            }
            catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }
}

