package com.guessgame.services;

import com.guessgame.models.User;

public class UserService {
    public static String localId;
    public static User user;
    public static String idToken;
}
