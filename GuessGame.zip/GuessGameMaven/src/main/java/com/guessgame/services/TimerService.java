package com.guessgame.services;

import java.util.HashMap;

public class TimerService {
    public static HashMap<Integer, Integer> questionTimes = new HashMap<>();
    public static int questionSize = QuestionService.MAX_QUESTION_SIZE + 1;

    public static void setCurrentQuestionTime(int questionNumber, int timeRemaining) {
        questionTimes.put(questionNumber, timeRemaining);
    }

    public static int getCurrentQuestionTime(int questionNumber) {
        return questionTimes.get(questionNumber);
    }

    public static void setupCurrentQuestionTime() {
        for (int i = 1; i < questionSize; i++) {
            questionTimes.put(i, 60);
        }
    }
}
