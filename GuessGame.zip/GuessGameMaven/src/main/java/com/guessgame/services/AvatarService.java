package com.guessgame.services;

import com.guessgame.controllers.AvatarController;
import com.guessgame.views.Avatar;

import javax.swing.*;
import java.awt.event.ActionListener;

public class AvatarService {
    public static JLabel titleLabel = new JLabel(String.valueOf(AvatarService.AvatarText.TITLE));
    public static JLabel avatarNameLabel = new JLabel(String.valueOf(AvatarService.AvatarText.AVATAR_NAME));
    public static ButtonHandler buttonHandler = new AvatarService.ButtonHandler();
    public static JButton confirmButton = new JButton(String.valueOf(AvatarService.AvatarText.CONFIRM));
    public static JTextField avatarNameField = new JTextField();

    private static Avatar avatar = new Avatar();

    public static void openWindow() {
        avatar.setTitle("Avatar");
        avatar.setVisible(true);
        avatar.setBounds(10, 10, 400, 400);
        avatar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        avatar.setResizable(false);
        avatar.setupTitleLabelAvatar();
        avatar.setupAvatarNameLabel();
        avatar.setupAvatarNameField();
        avatar.setupAvatarConfirmButton();
    }

    public static void closeWindow() {
        avatar.dispose();
    }

    public enum AvatarText {
        TITLE("Avatar"),
        AVATAR_NAME("Avatar Name: "),
        CONFIRM("Ok");

        private String avatarText;

        AvatarText(String avatarText) {
            this.avatarText = avatarText;
        }

        @Override
        public String toString() {
            return avatarText;
        }
    }

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            String cmd = e.getActionCommand();
            AvatarController.performButtonHandlerAction(cmd);
        }
    }
}
