package com.guessgame.services;

public class ScoreService {
    public static int score = 0;
    public static int attempts = 0;
}