package com.guessgame.services;

import com.guessgame.controllers.ForgotPasswordController;
import com.guessgame.views.ForgotPassword;

import javax.swing.*;
import java.awt.event.ActionListener;

public class ForgotPasswordService {
    public static JLabel titleLabel = new JLabel(String.valueOf(ForgotPasswordTest.FORGOT_PASSWORD));
    public static JLabel emailLabel = new JLabel(String.valueOf(ForgotPasswordTest.EMAIL_LABEL));
    public static JTextField emailTextField = new JTextField();
    public static ForgotPasswordService.ButtonHandler buttonHandler = new ForgotPasswordService.ButtonHandler();
    public static JButton confirmButton = new JButton(String.valueOf(ForgotPasswordTest.CONFIRM));
    private static ForgotPassword forgotPassword = new ForgotPassword();

    public static void openWindow() {
        forgotPassword.setTitle("Forgot Password");
        forgotPassword.setVisible(true);
        forgotPassword.setBounds(10, 10, 400, 400);
        forgotPassword.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        forgotPassword.setResizable(false);
        forgotPassword.setupForgotPasswordTitleLabel();
        forgotPassword.setupForgotPasswordEmailField();
        forgotPassword.setupForgotPasswordEmailLabel();
    }

    public static void closeWindow() {
        forgotPassword.dispose();
    }

    public enum ForgotPasswordTest {
        FORGOT_PASSWORD("Forgot Password"),
        EMAIL_LABEL("Enter Email: "),
        PASSWORD_LABEL("Enter Password: "),
        CONFIRM("Ok");

        private String forgotPasswordText;

        ForgotPasswordTest(String forgotPasswordText) {
            this.forgotPasswordText = forgotPasswordText;
        }

        @Override
        public String toString() {
            return forgotPasswordText;
        }
    }

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            String cmd = e.getActionCommand();
            ForgotPasswordController.performButtonHandlerAction(cmd);
        }
    }
}
