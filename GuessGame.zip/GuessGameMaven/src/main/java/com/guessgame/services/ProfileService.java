package com.guessgame.services;

import com.guessgame.controllers.ProfileController;
import com.guessgame.views.Profile;

import javax.swing.*;
import java.awt.event.ActionListener;

public class ProfileService {
    public static JLabel titleLabel = new JLabel(String.valueOf(ProfileText.TITLE));
    public static JLabel photoLabel = new JLabel(String.valueOf(ProfileText.PHOTO));
    public static JLabel usernameLabel = new JLabel(String.valueOf(ProfileText.USERNAME));
    public static JLabel passwordLabel = new JLabel(String.valueOf(ProfileText.PASSWORD));
    public static JLabel firstNameLabel = new JLabel(String.valueOf(ProfileText.FIRSTNAME));
    public static JLabel lastNameLabel = new JLabel(String.valueOf(ProfileText.LASTNAME));
    public static JLabel emailLabel = new JLabel(String.valueOf(ProfileText.EMAIL));
    public static JLabel telephoneLabel = new JLabel(String.valueOf(ProfileText.TELEPHONE));
    public static JLabel dobLabel = new JLabel(String.valueOf(ProfileText.DOB));
    public static JLabel genderLabel = new JLabel(String.valueOf(ProfileText.GENDER));
    public static JLabel locationLabel = new JLabel(String.valueOf(ProfileText.LOCATION));
    public static JTextField usernameField = new JTextField();
    public static JPasswordField passwordField = new JPasswordField();
    public static JTextField firstNameField = new JTextField();
    public static JTextField lastNameField = new JTextField();
    public static JTextField emailField = new JTextField();
    public static JTextField telephoneField = new JTextField();
    public static JTextField dobField = new JTextField();
    public static JComboBox<String> genderField = new JComboBox<>(new String[]{"Male", "Female"});
    public static JTextArea locationField = new JTextArea();
    public static JScrollPane locationScrollPane = new JScrollPane(locationField);
    public static JButton saveButton = new JButton(String.valueOf(ProfileText.SAVE));
    public static JButton cancelButton = new JButton(String.valueOf(ProfileText.CANCEL));
    public static JButton editFNButton = new JButton(String.valueOf(ProfileText.EDIT_FIRST_NAME));
    public static JButton editLNButton = new JButton(String.valueOf(ProfileText.EDIT_LAST_NAME));
    public static JButton editEmailButton = new JButton(String.valueOf(ProfileText.EDIT_EMAIL));
    public static JButton editUsernameButton = new JButton(String.valueOf(ProfileText.EDIT_USERNAME));
    public static JButton editPhoneButton = new JButton(String.valueOf(ProfileText.EDIT_PHONE));
    public static JButton editPasswordButton = new JButton(String.valueOf(ProfileText.EDIT_PASSWORD));
    public static JButton editDobButton = new JButton(String.valueOf(ProfileText.EDIT_DOB));
    public static JButton editGenderButton = new JButton(String.valueOf(ProfileText.EDIT_GENDER));
    public static JButton editLocationButton = new JButton(String.valueOf(ProfileText.EDIT_LOCATION));
    public static JButton uploadButton = new JButton(String.valueOf(ProfileText.UPLOAD));
    public static JButton deleteButton = new JButton(String.valueOf(ProfileText.DELETE));
    public static JButton downloadAccountButton = new JButton(String.valueOf(ProfileText.DOWNLOAD_ACCOUNT));
    public static ButtonHandler buttonHandler = new ButtonHandler();
    public static JLabel photo = new JLabel();
    public static JButton deleteAccountButton = new JButton(String.valueOf(ProfileText.DELETE_ACCOUNT));
    private static com.guessgame.views.Profile profile = new com.guessgame.views.Profile();

    public static void openWindow() {
        profile.setTitle("Profile");
        profile.setVisible(true);
        profile.setBounds(10, 10, 1100, 650);
        profile.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        profile.setResizable(false);
        Profile.setupTitleLabel();
        Profile.setupFirstNameLabel();
        Profile.setupLastNameLabel();
        Profile.setupUsernameLabel();
        Profile.setupEmailLabel();
        Profile.setupPhoneLabel();
        Profile.setupPasswordLabel();
        Profile.setupDobLabel();
        Profile.setupGenderLabel();
        Profile.setupLocationLabel();
        Profile.setupPhotoLabel();
        Profile.setupFirstNameField();
        Profile.setupLastNameField();
        Profile.setupUsernameField();
        Profile.setupEmailField();
        Profile.setupDobField();
        Profile.setupPhoneField();
        Profile.setupPasswordField();
        Profile.setupLocationField();
        firstNameField.setText(UserService.user.firstName);
        lastNameField.setText(UserService.user.lastName);
        emailField.setText(UserService.user.email);
        usernameField.setText(UserService.user.username);
        telephoneField.setText(UserService.user.telephone);
        dobField.setText(UserService.user.dateOfBirth);
        if (UserService.user.gender != null) {
            if (UserService.user.gender == 0) {
                genderField.setSelectedIndex(0);
            } else {
                genderField.setSelectedIndex(1);
            }
        } else {
            genderField.setSelectedIndex(0);
        }
        locationField.setText(UserService.user.location);
    }

    public static void closeWindow() {
        profile.dispose();
    }

    public enum ProfileText {
        TITLE("Profile"),
        PROFILE("Profile"),
        PHOTO("Photo: "),
        USERNAME("Username:"),
        PASSWORD("Password:"),
        SAVE("Save"),
        CANCEL("Cancel"),
        EDIT_FIRST_NAME("Edit"),
        EDIT_LAST_NAME("Edit"),
        EDIT_EMAIL("Edit"),
        EDIT_USERNAME("Edit"),
        EDIT_PHONE("Edit"),
        EDIT_PASSWORD("Edit"),
        EDIT_DOB("Edit"),
        EDIT_GENDER("Edit"),
        EDIT_LOCATION("Edit"),
        FIRSTNAME("First Name:"),
        LASTNAME("Last Name:"),
        EMAIL("Email:"),
        TELEPHONE("Telephone:"),
        DOB("Date of Birth:"),
        GENDER("Gender:"),
        LOCATION("Location:"),
        UPLOAD("Upload"),
        DELETE("Delete"),
        DELETE_ACCOUNT("Delete Account"),
        DOWNLOAD_ACCOUNT("Download Account");

        private String profileText;

        ProfileText(String loginText) {
            this.profileText = loginText;
        }

        @Override
        public String toString() {
            return profileText;
        }
    }

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            String cmd = e.getActionCommand();
            ProfileController.performButtonHandlerAction(cmd);
        }
    }
}