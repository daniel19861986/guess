package com.guessgame.services;

import com.guessgame.controllers.AuthController;
import com.guessgame.controllers.LoginController;
import com.guessgame.controllers.RegisterController;

import java.awt.event.*;
import java.sql.SQLException;

public class AuthService {
    public static ButtonHandler buttonHandler = new ButtonHandler();
    public static LabelHandler labelHandler = new LabelHandler();
    public static LabelHandlerRegister labelHandlerRegister = new LabelHandlerRegister();
    public static ItemHandler itemHandler = new ItemHandler();

    public static class ButtonHandler implements ActionListener {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            String cmd = e.getActionCommand();
            try {
                AuthController.performButtonHandlerAction(cmd);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static class ItemHandler implements ItemListener {
        public void itemStateChanged(ItemEvent event) {
            AuthController.performItemHandlerAction(event);
        }
    }

    public static class LabelHandlerRegister implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
            LoginController.onLoginClick();
        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {

        }
    }

    public static class LabelHandler implements MouseListener {
        @Override
        public void mouseClicked(MouseEvent event) {
            RegisterController.onRegisterButtonClick();
        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {
        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {
        }

        @Override
        public void mouseEntered(MouseEvent event) {
        }

        @Override
        public void mouseExited(MouseEvent event) {
        }
    }
}