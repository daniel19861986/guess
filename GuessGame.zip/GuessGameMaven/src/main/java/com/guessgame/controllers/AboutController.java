package com.guessgame.controllers;

import com.guessgame.services.AboutService;

public class AboutController {

    public static void performButtonHandlerAction(String cmd){
        if(cmd.equals("Ok")){
           onConfirmButtonClick();
        }
    }

    public static void onAboutSoftwareClick(){
        AboutService.openWindow();
    }

    private static void onConfirmButtonClick(){
        AboutService.closeWindow();
    }
}


