package com.guessgame.controllers;

import com.guessgame.models.UserProfile;
import com.guessgame.services.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Objects;

import static com.guessgame.controllers.QuestionController.checkIfQuestionAnswered;

public class GameController {
    public static JPanel setupQuestionNumberPanel() {
        ImageIcon image = null;
        try {
            image = new ImageIcon(ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("questionTick.png"))).getScaledInstance(20, 20, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i = 1; i < 21; i++) {
            GameService.buttons[i] = new JButton(String.valueOf(i));
            GameService.buttons[i].setIcon(image);
            GameService.buttons[i].setBackground(Color.LIGHT_GRAY);
            GameService.buttons[i].setHorizontalTextPosition(AbstractButton.CENTER);
            GameService.buttons[i].setVerticalTextPosition(AbstractButton.BOTTOM);
            GameService.buttons[i].addActionListener(GameService.buttonHandler);
            GameService.questionNumberPanel.add(GameService.buttons[i]);
        }
        GridLayout questionNumberGridLayout = new GridLayout(5, 4, 7, 7);
        GameService.questionNumberPanel.setLayout(questionNumberGridLayout);
        GameService.questionNumberPanel.setBackground(new Color(0, 128, 0));
        GameService.questionNumberPanel.setBorder(BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));
        GameService.questionNumberPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 0), 3));
        return GameService.questionNumberPanel;
    }

    public static void performButtonHandlerAction(String cmd) {
        if (cmd.equals(GameService.GuiText.QUIT.toString())) {
            System.exit(0);
        } else if (cmd.equals(GameService.GuiText.START.toString())) {
            GameController.onStartButtonClick();
        } else if (cmd.contains(GameService.GuiText.PAUSE.toString())) {
            GameController.onPauseButtonClick();
        } else if (cmd.equals(GameService.GuiText.PREVIOUS.toString())) {
            GameController.onPreviousButtonClick();
        } else if (cmd.equals(GameService.GuiText.SUBMIT.toString())) {
            GameController.onSubmitButtonClick();
        } else if (cmd.equals(GameService.GuiText.NEXT.toString())) {
            GameController.onNextButtonClick();
        } else if (cmd.equals(GameService.GuiText.RESUME.toString())) {
            GameController.onResumeButtonClick();
        } else if (cmd.equals(GameService.GuiText.SEND.toString())) {
            GameController.onSendButtonClick();
        } else if (cmd.equals(GameService.GuiText.RANKING.toString())) {
            //RankingController.onRankingChart();
            GameController.onRankingButtonClick();
        } else if (cmd.equals(GameService.GuiText.NEW_GAME.toString())) {
            GameController.onNewGameMenuItemClick();
        } else if (cmd.equals(ProfileService.ProfileText.PROFILE.toString())) {
            ProfileController.onProfileClick();
        } else if (cmd.equals(AboutService.AboutText.ABOUT.toString())) {
            AboutController.onAboutSoftwareClick();
        } else {
            if (UtilService.isNumeric(cmd)) {
                GameController.onQuestionPanelButtonClick(Integer.parseInt(cmd));
            } else {
                GameService.textEntryArea.setText(cmd);
            }
        }
    }

    private static void onQuestionPanelButtonClick(int questionNumber) {
        QuestionService.questionIndex = questionNumber - 1;
        clearQuestionValues();
        QuestionController.selectQuestion();
        clearQuestionValues();
        setupPreviousButton();
        setupNextButton();
        setCurrentQuestionTimer();
        setCurrentQuestionResponses();
        boolean questionAnswered = checkIfQuestionAnswered();
        if (questionAnswered) {
            QuestionController.displayAnswer();
            if (GameService.gamePlayTimer.isRunning()) {
                GameService.gamePlayTimer.stop();
            }
        }
    }

    private static void onNewGameMenuItemClick() {
        if (ScoreService.score > 0) {
            if (GameService.gamePlayTimer != null) {
                GameService.gamePlayTimer.stop();
            }
            disablePrimaryButtons();
            disableQuestionButtons();
            GameService.restartGameText = String.format("Congratulations! You finished the game with score of %d. Would you like to play again?", ScoreService.score);
            restartGame();
        } else {
            TimerService.setupCurrentQuestionTime();
            QuestionService.setupCurrentQuestionResponses();

            initialiseGamePlayTimer(TimerService.getCurrentQuestionTime(1));
            initialiseGamePauseTimer();

            if (GameService.gamePauseTimer.isRunning()) {
                GameService.gamePauseTimer.stop();
            }
            if (GameService.gamePlayTimer.isRunning()) {
                GameService.gamePlayTimer.stop();
            }
            GameService.gamePlayTimer.start();

            QuestionController.resetQuestions();
            startGame();
        }

    }

    private static void onRankingButtonClick() {
        RankingService.openWindow();
    }

    static void onSubmitButtonClick() {
        GameService.gamePlayTimer.stop();
        disablePrimaryButtons();
        disableQuestionButtons();
        GameService.restartGameText = String.format("Congratulations! You finished the game with score of %d. Would you like to play again?", ScoreService.score);
        DataService.setScore();
        restartGame();
    }

    private static void onPauseButtonClick() {
        if (GameService.gamePlayTimer.isRunning()) {
            GameService.gamePlayTimer.stop();
            GameService.pauseButton.setEnabled(false);
            GameService.resumeButton.setEnabled(true);
            GameService.nextButton.setEnabled(false);
            GameService.previousButton.setEnabled(false);
            GameService.gamePauseTimer.start();
        }
        GameController.decrementPausesRemaining();
    }

    private static void onResumeButtonClick() {
        if (GameService.gamePauseTimer.isRunning()) {
            GameService.gamePauseTimer.stop();
            GameService.pauseButton.setEnabled(true);
            GameService.resumeButton.setEnabled(false);
            GameService.nextButton.setEnabled(true);
            GameService.previousButton.setEnabled(true);
            GameService.gamePlayTimer.start();
        }
    }

    private static void decrementPausesRemaining() {
        if (GameService.pausesRemaining > 0) {
            GameService.pausesRemaining = GameService.pausesRemaining - 1;
            GameService.pauseButton.setText(String.format("Pause (%d)", GameService.pausesRemaining));
        } else {
            JOptionPane.showMessageDialog(null, "Sorry! You cannot pause the game anymore.");
        }
    }

    private static void onPreviousButtonClick() {
        QuestionController.selectPreviousQuestion();
        clearQuestionValues();
        setupPreviousButton();
        setupNextButton();
        setCurrentQuestionResponses();
        if (checkIfQuestionAnswered()) {
            disableQuestionButtons();
            QuestionController.displayAnswer();
            GameService.gamePlayTimer.stop();
            GameService.gamePauseTimer.stop();
        } else {
            setCurrentQuestionTimer();
            GameService.gamePlayTimer.start();
            enableQuestionButtons();
        }
    }

    private static void clearQuestionValues() {
        GameService.alertMessage = "";
        GameService.guesses = "";
        GameService.textEntryArea.setText("");
    }

    private static void setCurrentQuestionTimer() {
        if (GameService.gamePauseTimer.isRunning()) {
            GameService.gamePauseTimer.stop();
        }
        if (GameService.gamePlayTimer.isRunning()) {
            GameService.gamePlayTimer.stop();
        }
        initialiseGamePlayTimer(TimerService.getCurrentQuestionTime(QuestionService.questionIndex + 1));
        GameService.gamePlayTimer.start();
    }


    private static void setCurrentQuestionResponses() {
        if (QuestionService.getCurrentQuestionResponse(QuestionService.questionIndex + 1) != null) {
            GameService.guesses = QuestionService.getCurrentQuestionResponse(QuestionService.questionIndex + 1);
            GameService.submitButton.setEnabled(false);
            GameService.resumeButton.setEnabled(false);
            GameService.sendButton.setEnabled(false);
            GameService.pauseButton.setEnabled(false);
            GameService.resumeButton.setEnabled(false);
            for (JButton b : GameService.alphanumericButtons) {
                b.setEnabled(false);
            }
        } else {
            GameService.submitButton.setEnabled(true);
            GameService.sendButton.setEnabled(true);
            if (GameService.pausesRemaining > 0) {
                GameService.pauseButton.setEnabled(true);
                GameService.resumeButton.setEnabled(true);
            }
            for (JButton b : GameService.alphanumericButtons) {
                b.setEnabled(true);
            }
        }
    }

    private static void enableQuestionButtons() {
    }

    static void onNextButtonClick() {
        QuestionController.selectNextQuestion();
        clearQuestionValues();
        setupPreviousButton();
        setupNextButton();
        setCurrentQuestionTimer();
        setCurrentQuestionResponses();
        boolean questionAnswered = checkIfQuestionAnswered();
        if (questionAnswered) {
            QuestionController.displayAnswer();
            if (GameService.gamePlayTimer.isRunning()) {
                GameService.gamePlayTimer.stop();
            }
        }
    }

    private static void setupPreviousButton() {
        if (QuestionService.questionIndex > 0) {
            GameService.previousButton.setEnabled(true);
        } else {
            GameService.previousButton.setEnabled(false);
        }
    }

    private static void setupNextButton() {
        if (QuestionService.questionIndex == QuestionService.MAX_QUESTION_SIZE - 1) {
            GameService.nextButton.setEnabled(false);
        } else {
            GameService.nextButton.setEnabled(true);
        }
    }

    public static JLabel setupHiddenVerticallyCenteredLabel() {
        GameService.hiddenVerticallyCenteredLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 18));
        GameService.hiddenVerticallyCenteredLabel.setForeground(new Color(0, 128, 0));
        GameService.hiddenVerticallyCenteredLabel.setText("Hidden Label");
        return GameService.hiddenVerticallyCenteredLabel;
    }

    public static JPanel setupIntermediaryPanel() {
        GameService.intermediaryPanel.setBackground(new Color(0, 128, 0));
        GameService.intermediaryPanel.setOpaque(false);
        GameService.intermediaryPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 128, 0)));
        GameService.intermediaryPanel.setLayout(new BoxLayout(GameService.intermediaryPanel, BoxLayout.Y_AXIS));
        GameService.intermediaryPanel.add(GameController.setupScoreboardPanel());
        GameService.intermediaryPanel.add(GameController.setupClusterPanel());
        return GameService.intermediaryPanel;
    }

    private static JPanel setupClusterPanel() {
        GameService.clusterPanel.setOpaque(false);
        GameService.clusterPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 128, 0)));

        GroupLayout clusterPanelGroupLayout = new GroupLayout(GameService.clusterPanel);
        GameService.clusterPanel.setLayout(clusterPanelGroupLayout);
        clusterPanelGroupLayout.setHorizontalGroup(
                clusterPanelGroupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGap(0, 17, Short.MAX_VALUE)
        );
        clusterPanelGroupLayout.setVerticalGroup(
                clusterPanelGroupLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGap(0, 10, Short.MAX_VALUE)
        );

        return GameService.clusterPanel;
    }

    private static JPanel setupScoreboardPanel() {
        GameService.scoreboardPanel.setBorder(BorderFactory.createTitledBorder(null, "SCOREBOARD", javax.swing.border.TitledBorder.CENTER, TitledBorder.TOP, new java.awt.Font("Tahoma", Font.PLAIN, 11), new Color(0, 0, 0)));
        TitledBorder titledBorder = (TitledBorder) GameService.scoreboardPanel.getBorder();
        titledBorder.setTitleColor(Color.BLACK);
        GameService.scoreboardPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
        GameService.scoreboardPanel.setOpaque(false);
        GameService.scoreboardPanel.setLayout(new GridLayout(2, 1, 0, 0));

        // TODO: Duplicate code!
        try {
            UserProfile.profile = ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("profile.jpg")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        ImageIcon imageIcon = new ImageIcon(UserProfile.profile);
        Image tempImage = imageIcon.getImage();
        Image image = tempImage.getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(image);
        GameService.photo = new JLabel(imageIcon);
        GameService.scoreboardPanel.add(GameService.photo);
        GameService.avatarName.setFont(new Font("Trebuchet MS", Font.PLAIN, 20));
        GameService.avatarName.setText(UserService.user.username);
        GameService.scoreboardPanel.add(GameService.avatarName);
        GameService.scoreLabel.setFont(new Font("Trebuchet MS", 0, 20));
        GameService.scoreLabel.setText(" Score: " + ScoreService.score);
        GameService.scoreboardPanel.add(GameService.scoreLabel);

        return GameService.scoreboardPanel;
    }

    public static JPanel setupCenterPanel() {
        GameService.centerPanel.setBackground(new Color(0, 128, 0));
        GameService.centerPanel.setSize(500, 500);
        GameService.centerPanel.setBorder(BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));
        GameService.centerPanel.setOpaque(false);
        GameService.centerPanel.setLayout(new BoxLayout(GameService.centerPanel, BoxLayout.Y_AXIS));
        GameService.centerPanel.add(GameController.setupMainPanel());
        GameService.centerPanel.add(GameController.setupTextEntryPanel());
        GameService.centerPanel.add(GameController.setupButtonOptionsPanel());
        GameService.centerPanel.add(GameController.setupAlphanumericPanel());
        return GameService.centerPanel;
    }

    private static JPanel setupAlphanumericPanel() {
        GameService.alphanumericPanel.setOpaque(false);
        GameService.alphanumericPanel.setBackground(new Color(0, 128, 0));
        GameService.alphanumericPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 0), 3));
        GameService.alphanumericPanel.setLayout(new GridLayout(0, 10, 5, 5));

        for (char alphabet = '0'; alphabet <= '9'; alphabet++) {
            JButton button = new JButton(String.valueOf(alphabet).toUpperCase());
            button.addActionListener(GameService.buttonHandler);
            button.setFont(new Font("Helvetica", Font.PLAIN, 20));
            GameService.alphanumericPanel.add(button);
            GameService.alphanumericButtons.add(button);
        }

        for (char alphabet = 'a'; alphabet <= 'z'; alphabet++) {
            JButton button = new JButton(String.valueOf(alphabet).toUpperCase());
            button.addActionListener(GameService.buttonHandler);
            button.setFont(new Font("Helvetica", Font.PLAIN, 20));
            GameService.alphanumericPanel.add(button);
            GameService.alphanumericButtons.add(button);
        }

        return GameService.alphanumericPanel;
    }

    private static JPanel setupButtonOptionsPanel() {
        GameService.buttonOptionsPanel.setOpaque(false);
        GameService.startButton.addActionListener(GameService.buttonHandler);
        GameService.buttonOptionsPanel.add(GameService.startButton);
        GameService.pauseButton.addActionListener(GameService.buttonHandler);
        GameService.buttonOptionsPanel.add(GameService.pauseButton);
        GameService.resumeButton.addActionListener(GameService.buttonHandler);
        GameService.buttonOptionsPanel.add(GameService.resumeButton);
        GameService.submitButton.addActionListener(GameService.buttonHandler);
        GameService.buttonOptionsPanel.add(GameService.submitButton);
        GameService.quitButton.addActionListener(GameService.buttonHandler);
        GameService.buttonOptionsPanel.add(GameService.quitButton);
        GameService.buttonOptionsPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
        return GameService.buttonOptionsPanel;
    }

    private static JPanel setupTextEntryPanel() {
        GameService.textEntryPanel.setMaximumSize(new Dimension(2147483647, 100));
        GameService.textEntryPanel.setOpaque(false);
        GameService.textEntryPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 3));
        GameService.textEntryPanel.setPreferredSize(new Dimension(334, 64));
        GameService.textEntryPanel.setLayout(new BorderLayout());
        GameService.sendButton.addActionListener(GameService.buttonHandler);
        GameService.textEntryPanel.add(GameService.sendButton, BorderLayout.LINE_END);
        GameService.scrollPane.setViewportView(GameController.setupTextEntryArea());
        GameService.textEntryPanel.add(GameService.scrollPane, BorderLayout.CENTER);
        return GameService.textEntryPanel;
    }

    private static JTextArea setupTextEntryArea() {
        GameService.textEntryArea.setColumns(20);
        GameService.textEntryArea.setRows(1);
        GameService.textEntryArea.setToolTipText("");
        GameService.textEntryArea.setFont(new Font("Helvetica", Font.PLAIN, 18));
        GameService.textEntryArea.setWrapStyleWord(true);
        GameService.textEntryArea.setEditable(true);
        GameService.textEntryArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    if (GameService.textEntryArea.getText().trim().length() > 0) {
                        GameService.sendButton.doClick();
                    }
                }
            }
        });
        return GameService.textEntryArea;
    }

    private static JPanel setupMainPanel() {
        GameService.mainPanel.setOpaque(false);
        GameService.mainPanel.setLayout(new BorderLayout());
        GameService.mainPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 0), 3));
        GameService.mainPanel.add(GameController.setupQuestionLabel(), BorderLayout.PAGE_START);

        GameService.previousButton.addActionListener(GameService.buttonHandler);
        GameService.nextButton.addActionListener(GameService.buttonHandler);
        GameService.mainPanel.add(GameService.previousButton, BorderLayout.LINE_START);
        GameService.mainPanel.add(GameService.nextButton, BorderLayout.LINE_END);
        GameService.mainPanel.add(GameService.display, BorderLayout.CENTER);
        return GameService.mainPanel;
    }

    private static JLabel setupQuestionLabel() {
        GameService.questionLabel.setFont(new Font("Helvetica", 0, 18));
        GameService.questionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        return GameService.questionLabel;
    }

    static void disableQuestionButtons() {
        GameService.startButton.setEnabled(true);
        GameService.pauseButton.setEnabled(false);
        GameService.submitButton.setEnabled(false);
        GameService.resumeButton.setEnabled(false);
        GameService.sendButton.setEnabled(false);
        for (JButton b : GameService.alphanumericButtons) {
            b.setEnabled(false);
        }
    }

    public static JPanel setupTimerPanel() {
        GameService.timerPanel.setOpaque(false);
        GameService.timerPanel.setLayout(new FlowLayout(java.awt.FlowLayout.RIGHT));
        GameService.timerLabel.setFont(new java.awt.Font("Helvetica", Font.PLAIN, 18));
        GameService.timerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        GameService.timerLabel.setText("01:00");
        GameService.timerLabel.setBorder(BorderFactory.createTitledBorder(null, "TIMER", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.BELOW_TOP, new Font("Trebuchet MS", Font.PLAIN, 12), new Color(0, 0, 0)));
        GameService.timerLabel.setMaximumSize(new Dimension(100, 51));
        GameService.timerLabel.setMinimumSize(new Dimension(100, 51));
        GameService.timerLabel.setPreferredSize(new Dimension(100, 51));
        GameService.timerPanel.add(GameService.timerLabel);
        return GameService.timerPanel;
    }

    public static void disablePrimaryButtons() {
        GameService.startButton.setEnabled(true);
        GameService.nextButton.setEnabled(false);
        GameService.pauseButton.setEnabled(false);
        GameService.submitButton.setEnabled(false);
        GameService.resumeButton.setEnabled(false);
        GameService.previousButton.setEnabled(false);
        GameService.sendButton.setEnabled(false);
        for (JButton b : GameService.alphanumericButtons) {
            b.setEnabled(false);
        }
    }

    private static void onStartButtonClick() {
        TimerService.setupCurrentQuestionTime();
        QuestionService.setupCurrentQuestionResponses();

        initialiseGamePlayTimer(TimerService.getCurrentQuestionTime(1));
        initialiseGamePauseTimer();

        if (GameService.gamePauseTimer.isRunning()) {
            GameService.gamePauseTimer.stop();
        }
        if (GameService.gamePlayTimer.isRunning()) {
            GameService.gamePlayTimer.stop();
        }
        GameService.gamePlayTimer.start();

        startGame();
    }

    private static void startGame() {
        GameService.guesses = "";
        GameService.badGuesses = 0;
        GameService.startButton.setEnabled(false);
        GameService.previousButton.setEnabled(false);
        GameService.nextButton.setEnabled(true);
        GameService.submitButton.setEnabled(true);
        GameService.sendButton.setEnabled(true);
        GameService.pauseButton.setEnabled(true);
        GameService.pauseButton.setText(String.format("Pause (%d)", GameService.pausesRemaining));

        for (JButton b : GameService.alphanumericButtons) {
            b.setEnabled(true);
        }

        QuestionController.selectInitialQuestion();
    }

    private static void initialiseGamePauseTimer() {
        GameService.gamePauseTimer = new Timer(1000, new ActionListener() {
            int time = 10;

            @Override
            public void actionPerformed(ActionEvent e) {
                time--;
                GameService.timerLabel.setText(format(time / 60) + ":" + format(time % 60));
                if (time == 0) {
                    JOptionPane.showMessageDialog(null, "You have run out of time and cannot pause any longer!");
                    GameService.pauseButton.setEnabled(false);
                    GameService.resumeButton.setEnabled(false);
                    GameService.previousButton.setEnabled(true);
                    GameService.nextButton.setEnabled(true);
                    if (GameService.gamePauseTimer.isRunning()) {
                        GameService.gamePauseTimer.stop();
                        GameService.gamePlayTimer.start();
                    }
                    GameService.pausesRemaining = 0;
                    GameService.pauseButton.setText(String.format("Pause (%d)", GameService.pausesRemaining));
                }
            }
        });
    }

    private static void initialiseGamePlayTimer(int setTime) {
        GameService.gamePlayTime = setTime;
        GameService.gamePlayTimer = new Timer(1000, e -> {
            GameService.gamePlayTime--;
            TimerService.setCurrentQuestionTime(QuestionService.questionIndex + 1, GameService.gamePlayTime);
            GameService.timerLabel.setText(format(GameService.gamePlayTime / 60) + ":" + format(GameService.gamePlayTime % 60));
            if (GameService.gamePlayTime == 0) {
                GameService.gamePlayTimer = (Timer) e.getSource();
                GameService.gamePlayTimer.stop();
                disableQuestionButtons();
                disablePrimaryButtons();
                GameService.restartGameText = "Sorry your time is up. You finished the game with score of" + ScoreService.score + ". Would you like to play again?";
                restartGame();
            }
        });
    }

    private static void restartGame() {
        int restartGame = JOptionPane.showConfirmDialog(
                null,
                GameService.restartGameText,
                "Submit",
                JOptionPane.YES_NO_OPTION);
        if (restartGame == JOptionPane.YES_OPTION) {
            GameService.closeWindow();
            AvatarService.openWindow();
            QuestionController.resetQuestions();
        } else {
            GameService.closeWindow();
            LoginService.openWindow();
        }
    }

    private static String format(int i) {
        String result = String.valueOf(i);
        if (result.length() == 1) {
            result = "0" + result;
        }
        return result;
    }

    private static void onSendButtonClick() {
        try {
            QuestionController.processQuestionResponse(GameService.textEntryArea.getText());
            if (QuestionController.checkifAllQuestionsAnswered()) {
                GameController.onSubmitButtonClick();
            }
            GameService.textEntryArea.setText("");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static JPanel setupToolbarPanel() {
        GameService.toolbarPanel.setOpaque(false);
        GameService.toolbarPanel.setBackground(new Color(50, 205, 50));
        GameService.toolbarPanel.setBorder(BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.BELOW_TOP, new Font("Helvetica", Font.PLAIN, 12), new Color(0, 0, 0)));
        GameService.toolbarPanel.setLayout(new BorderLayout());
        GameService.toolbarPanel.add(GameService.toolbar, BorderLayout.CENTER);
        ImageIcon newGameIcon = null;
        try {
            newGameIcon = new ImageIcon(ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("new_game.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }

        Action openAction = new AbstractAction("New Game", newGameIcon) {
            @Override
            public void actionPerformed(ActionEvent e) {
                onNewGameMenuItemClick();
            }
        };

        GameService.toolbar.add(openAction);
        GameService.toolbar.addSeparator();

        ImageIcon rankingIcon = null;

        try {
            rankingIcon = new ImageIcon(ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("ranking.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }

        Action rankingAction = new AbstractAction("Ranking", rankingIcon) {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameController.onRankingButtonClick();
            }
        };

        GameService.toolbar.add(rankingAction);

        ImageIcon profileIcon = null;

        try {
            profileIcon = new ImageIcon(ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("profileIcon.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }

        Action profileAction = new AbstractAction("Profile", profileIcon) {
            @Override
            public void actionPerformed(ActionEvent e) {
                ProfileController.onProfileClick();
            }
        };

        GameService.toolbar.add(profileAction);

        ImageIcon aboutIcon = null;

        try {
            aboutIcon = new ImageIcon(ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("about.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }

        Action aboutAction = new AbstractAction("Profile", aboutIcon) {
            @Override
            public void actionPerformed(ActionEvent e) {
                AboutController.onAboutSoftwareClick();
            }
        };

        GameService.toolbar.add(aboutAction);

        ImageIcon rulesIcon = null;

        try {
            rulesIcon = new ImageIcon(ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("rules.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }

        Action rulesAction = new AbstractAction("Rules", rulesIcon) {
            @Override
            public void actionPerformed(ActionEvent e) {
                RulesController.onRulesClick();
            }
        };

        GameService.toolbar.add(rulesAction);

        ImageIcon logoutIcon = null;
        try {
            logoutIcon = new ImageIcon(ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("logout.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }

        Action logoutAction = new AbstractAction("Logout", logoutIcon) {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    AuthController.onLogoutClick();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        };

        GameService.toolbar.add(logoutAction);
        return GameService.toolbarPanel;
    }
}