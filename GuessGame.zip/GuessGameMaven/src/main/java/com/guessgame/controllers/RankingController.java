package com.guessgame.controllers;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QuerySnapshot;
import com.guessgame.models.Ranking;
import com.guessgame.services.FirebaseService;
import com.guessgame.services.RankingService;

import java.util.ArrayList;
import java.util.List;

public class RankingController {

    public static void performButtonHandlerAction(String cmd){
        if(cmd.equals(RankingService.RankingText.OK.toString())){
            onButtonOkClick();
        }
    }

    public static List<Ranking> getRankings(String collectionName, String field) {
        List<Ranking> results = new ArrayList<>();
        try {
            CollectionReference collectionRef = FirebaseService.db.collection(collectionName);
            Query query = collectionRef.orderBy(field, Query.Direction.DESCENDING).limit(10);
            ApiFuture<QuerySnapshot> querySnapshot = query.get();
            for (DocumentSnapshot document : querySnapshot.get().getDocuments()) {
                results.add(new Ranking(document.getString("gameSessionId"),
                        document.getString("name"),
                        Math.toIntExact(document.getLong("score"))));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return results;
    }

    private static void onButtonOkClick(){
        RankingService.closeWindow();
    }
}