package com.guessgame.controllers;

import com.google.common.collect.ImmutableList;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.guessgame.models.Question;
import com.guessgame.services.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.*;

public class QuestionController {
    public static void getQuestions() {
        List<Question> questionList = FirebaseService.getQuestionDocumentsAsEntity("questions", "questionsData");
        Collections.shuffle(questionList);
        QuestionService.questionList = questionList.toArray(new Question[0]);
    }

    public static void selectInitialQuestion() {
        QuestionService.questionIndex = 0;
        selectQuestion();
    }

    static void selectQuestion() {
        Question question = QuestionService.questionList[QuestionService.questionIndex];
        GameService.message = String.format("%s. %s", (QuestionService.questionIndex + 1), question.getQuestion());
        GameService.answer = question.getAnswer().toUpperCase();
        if (checkifAllQuestionsAnswered()) {
            GameController.onSubmitButtonClick();
        }
    }

    static boolean checkifAllQuestionsAnswered() {
        return DataService.responses.size() == QuestionService.MAX_QUESTION_SIZE;
    }

    static boolean isEnoughGuessesRemaining() {
        return GameService.badGuesses < 2;
    }

    static boolean isProvidedLetterInWord(String response, int guessLetterIndex, int answerLetterIndex) {
        if (response.toUpperCase().charAt(guessLetterIndex) == GameService.answer.charAt(answerLetterIndex)) {
            System.out.println(String.format("%s matches %s (at index %s)", response.charAt(guessLetterIndex), GameService.answer, GameService.answer.charAt(answerLetterIndex)));
            return true;
        } else {
            return false;
        }
    }

    static void markLetterAsNotInWord(String response, int responseLetterIndex) {
        System.out.printf("%s does not exist in word %s%n", response.toUpperCase().charAt(responseLetterIndex), GameService.answer);
        GameService.alertMessage = String.format("Sorry, %s is not in the word. Pick your next letter.", response.toUpperCase());
        ScoreService.attempts++;
    }

    static void markLetterAsInWord(String response) {
        GameService.alertMessage = String.format("Yes, %s is in the word. Pick your next letter.", response.toUpperCase());
        if (wordIsComplete()) {
            markQuestionAsAnswered(1);
            Question question = QuestionService.questionList[QuestionService.questionIndex];
            QuestionService.setCurrentQuestionResponse(QuestionService.questionIndex + 1, GameService.answer);
            //GameService.alertMessage = String.format("Well done. You got the correct answer - %s. Click on \"Next\" to play again.", question.getAnswer());
            GameService.alertMessage = String.format("%s", question.getAnswer());
            GameService.gamePlayTimer.stop();
            GameService.gamePauseTimer.stop();
        }
    }

    private static void incrementUserScore() {
        if (wordIsComplete()) {
            if (GameService.badGuesses == 0 && QuestionService.guessesMade == 1) {
                ScoreController.incrementScore(15);
            } else {
                ScoreController.incrementScore(10);
            }
            System.out.printf("Number of bad guesses: %d%n", GameService.badGuesses);
            System.out.printf("Number of guesses made: %d%n", QuestionService.guessesMade);
            System.out.printf("Your current score is %d%n", ScoreService.score);
            GameService.badGuesses = 0;
            QuestionService.guessesMade = 0;
        }
    }

    static void goToNextQuestionIfNoChancesRemaining() {
        QuestionController.markQuestionAsAnswered(2);
        JOptionPane.showMessageDialog(null, "Sorry you have got the question wrong!");
        GameController.onNextButtonClick();
    }

    static void processQuestionResponse(String response) {
        QuestionService.guessesMade++;
        boolean matchFound = false;
        List<Boolean> incorrectAttempts = new ArrayList<>();
        for (int i = 0; i < response.length(); i++) {
            String guess = String.valueOf(response.toUpperCase().charAt(i));
            if (guess.trim().length() > 0) {
                GameService.guesses = String.format("%s%s", GameService.guesses, guess);
                if (isEnoughGuessesRemaining()) {
                    for (int j = 0; j < GameService.answer.length(); j++) {
                        matchFound = isProvidedLetterInWord(response, i, j);
                        if (matchFound) {
                            markLetterAsInWord(guess);
                            break;
                        }
                    }
                    if (!matchFound) {
                        markLetterAsNotInWord(response, i);
                        incorrectAttempts.add(false);
                    }
                } else {
                    goToNextQuestionIfNoChancesRemaining();
                }
            }
        }
        if (incorrectAttempts.size() > 0) {
            GameService.badGuesses++;
        }
        if (matchFound) {
            GameService.gamePlayTime += 5;
        }
        incrementUserScore();
    }

    private static boolean wordIsComplete() {
        String answerWithoutSpaces = GameService.answer.replaceAll(" ", "");
        for (int i = 0; i < answerWithoutSpaces.length(); i++) {
            char ch = answerWithoutSpaces.charAt(i);
            if (GameService.guesses.indexOf(ch) == -1) {
                return false;
            }
        }
        return true;
    }

    private static void markQuestionAsAnswered(int response) {
        ImageIcon image = null;
        DataService.setQuestionAsAnswered(response, QuestionService.questionList[QuestionService.questionIndex].getId());
        if (response == 1) {
            try {
                image = new ImageIcon(ImageIO.read(Objects.requireNonNull(QuestionController.class.getClassLoader().getResource("good.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
            } catch (IOException e) {
                e.printStackTrace();
            }
            GameService.buttons[QuestionService.questionIndex + 1].setIcon(image);
            GameService.buttons[QuestionService.questionIndex + 1].setBackground(Color.green);
            GameService.buttons[QuestionService.questionIndex + 1].setHorizontalTextPosition(AbstractButton.CENTER);
            GameService.buttons[QuestionService.questionIndex + 1].setVerticalTextPosition(AbstractButton.BOTTOM);
        }
        if (response == 2) {
            try {
                image = new ImageIcon(ImageIO.read(Objects.requireNonNull(QuestionController.class.getClassLoader().getResource("error.png"))).getScaledInstance(20, 20, Image.SCALE_DEFAULT));
            } catch (IOException e) {
                e.printStackTrace();
            }
            GameService.buttons[QuestionService.questionIndex + 1].setIcon(image);
            GameService.buttons[QuestionService.questionIndex + 1].setBackground(Color.red);
            GameService.buttons[QuestionService.questionIndex + 1].setHorizontalTextPosition(AbstractButton.CENTER);
            GameService.buttons[QuestionService.questionIndex + 1].setVerticalTextPosition(AbstractButton.BOTTOM);
        }
    }

    public static boolean checkIfQuestionAnswered() {
        if (QuestionService.questionIndex > -1) {
            return DataService.getQuestionAnswerStatus(QuestionService.questionList[QuestionService.questionIndex].getId());
        }
        return false;
    }

    public static void selectNextQuestion() {
        if (QuestionService.questionIndex < QuestionService.MAX_QUESTION_SIZE - 1) {
            QuestionService.questionIndex++;
            GameService.correctGuesses = 0;
            selectQuestion();
        } else {
            QuestionService.questionIndex = QuestionService.MAX_QUESTION_SIZE;
            GameService.message = "There are no more questions!";
        }
    }

    public static void selectPreviousQuestion() {
        if (QuestionService.questionIndex > 0) {
            if (QuestionService.questionIndex <= QuestionService.MAX_QUESTION_SIZE - 1 || QuestionService.questionIndex == QuestionService.MAX_QUESTION_SIZE) {
                QuestionService.questionIndex--;
                selectQuestion();
            }
        }
    }

    public static void displayAnswer() {
        Question question = QuestionService.questionList[QuestionService.questionIndex];
        GameService.alertMessage = question.getAnswer();
    }

    public static void resetQuestions() {
        getQuestions();
        ScoreController.resetScore();
        GameService.guesses = "";
        GameService.badGuesses = 0;
        GameService.textEntryArea.setText("");
        GameService.alertMessage = "";
        GameService.message = "";
        GameService.answer = "";
        GameController.disableQuestionButtons();
        QuestionService.questionIndex = -1;
        DataService.responses = new ArrayList<>();
        GameService.gameSessionId = String.valueOf(new Date().getTime());

        ImageIcon image = null;
        try {
            image = new ImageIcon(ImageIO.read(Objects.requireNonNull(QuestionController.class.getClassLoader().getResource("questionTick.png"))).getScaledInstance(30, 30, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i = 1; i < 21; i++) {
            GameService.buttons[i].setBackground(Color.LIGHT_GRAY);
            GameService.buttons[i].setIcon(image);
            GameService.buttons[i].setText(String.valueOf(i));
            GameService.buttons[i].setHorizontalTextPosition(AbstractButton.CENTER);
            GameService.buttons[i].setVerticalTextPosition(AbstractButton.BOTTOM);
        }
    }
}
