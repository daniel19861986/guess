package com.guessgame.controllers;

import com.guessgame.services.AvatarService;
import com.guessgame.services.GameService;

import javax.swing.*;

public class AvatarController {
    public static void performButtonHandlerAction(String cmd) {
        if (cmd.equals(String.valueOf(AvatarService.AvatarText.CONFIRM))) {
            onConfirmButtonClick();
        }
    }

    private static void onConfirmButtonClick() {
        if (AvatarService.avatarNameField.getText().trim().length() == 0) {
            JOptionPane.showMessageDialog(null, "Please enter your avatar name to continue.");
        } else {
            GameService.avatarName.setText(AvatarService.avatarNameField.getText());
            AvatarService.closeWindow();
            GameService.openWindow();
        }
    }
}
