package com.guessgame.controllers;

import com.guessgame.services.GameService;
import com.guessgame.services.ScoreService;

public class ScoreController {
    public static void incrementScore(int delta) {
        ScoreService.score = ScoreService.score + delta;
        System.out.println(String.format("Adding %d to score", delta));
        GameService.scoreLabel.setText(" Score: " + ScoreService.score);
    }

    public static void resetScore() {
        ScoreService.score = 0;
        GameService.scoreLabel.setText(String.format("Score: %d", ScoreService.score));
    }
}
