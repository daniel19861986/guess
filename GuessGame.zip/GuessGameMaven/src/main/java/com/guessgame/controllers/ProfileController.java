package com.guessgame.controllers;

import com.guessgame.models.UserProfile;
import com.guessgame.services.*;
import com.guessgame.views.Profile;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.PrintWriter;
import java.util.Objects;

public class ProfileController {
    static void onProfileClick() {
        ProfileService.openWindow();
    }

    public static void performButtonHandlerAction(String cmd) {
        if (cmd.equals(ProfileService.ProfileText.SAVE.toString())) {
            onSaveButtonClick();
        } else if (cmd.equals(ProfileService.ProfileText.CANCEL.toString())) {
            onCancelButtonClick();
        } else if (cmd.equals(ProfileService.ProfileText.UPLOAD.toString())) {
            onUploadButtonClick();
        } else if (cmd.equals(ProfileService.ProfileText.DELETE.toString())) {
            onDeleteButtonClick();
        } else if (cmd.equals(ProfileService.ProfileText.DELETE_ACCOUNT.toString())) {
            onDeleteAccountButtonClick();
        } else if (cmd.equals(ProfileService.ProfileText.DOWNLOAD_ACCOUNT.toString())) {
            onDownloadButtonClick();
        }
    }

    private static void onDownloadButtonClick() {
        String accountFile = "We currently have the following information about you on our servers:\r\n";
        accountFile += String.format("Date of Birth: %s\r\n", UserService.user.dateOfBirth);
        accountFile += String.format("First Name: %s\r\n", UserService.user.firstName);
        accountFile += String.format("Last Name: %s\r\n", UserService.user.lastName);
        String gender = "Male";
        if (UserService.user.gender == 1) {
            gender = "Female";
        }
        accountFile += String.format("Gender: %s\r\n", gender);
        accountFile += String.format("Username: %s\r\n", UserService.user.username);
        accountFile += String.format("Email: %s\r\n", UserService.user.email);
        accountFile += String.format("Location: %s\r\n", UserService.user.location);
        accountFile += String.format("Telephone: %s\r\n", UserService.user.telephone);
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("Download Account Details");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.showSaveDialog(null);
        String currentDirectory = chooser.getSelectedFile().toString();
        String saveDirectory = String.format("%s\\GuessGameAccountDetails.txt", currentDirectory);
        System.out.println(saveDirectory);
        try (PrintWriter out = new PrintWriter(saveDirectory)) {
            out.println(accountFile);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        JOptionPane.showMessageDialog(null, String.format("Your account details have been saved to %s", saveDirectory));
    }

    private static void onDeleteAccountButtonClick() {
        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete your account?", "Delete Account", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) {
            FirebaseService.deleteAccount();
        }
    }

    private static void onUploadButtonClick() {
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image Files", "jpg", "png", "gif", "jpeg");
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(filter);
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                UserProfile.profile = ImageIO.read(file);
                ProfileService.photo.setIcon(new ImageIcon(UserProfile.profile));
                ProfileService.photo.revalidate();
                ProfileService.photo.repaint();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static void onSaveButtonClick() {
        UserService.user.firstName = ProfileService.firstNameField.getText();
        UserService.user.lastName = ProfileService.lastNameField.getText();
        UserService.user.username = ProfileService.usernameField.getText();
        UserService.user.telephone = ProfileService.telephoneField.getText();
        UserService.user.gender = ProfileService.genderField.getSelectedIndex();
        UserService.user.dateOfBirth = ProfileService.dobField.getText();
        UserService.user.location = ProfileService.locationField.getText();
        GameService.avatarName.setText(UserService.user.username);
        DataService.setProfile();
        if(String.valueOf(ProfileService.passwordField.getPassword()).length() > 0) {
            FirebaseService.changeAccountPassword();
        }
        if(String.valueOf(ProfileService.emailField.getText()).length() > 0) {
            if(!String.valueOf(ProfileService.emailField.getText()).equals(UserService.user.email)) {
                UserService.user.email = ProfileService.emailField.getText();
                FirebaseService.changeAccountEmail();
                DataService.setProfile();
            }
        }
        Profile.setupFirstNameField();
        ProfileService.closeWindow();
    }

    public static void onEditFirstNameButtonClick() {
        ProfileService.editFNButton.addActionListener(event -> ProfileService.firstNameField.setEditable(true));
    }

    public static void onEditLastNameButtonClick() {
        ProfileService.editLNButton.addActionListener(event -> ProfileService.lastNameField.setEditable(true));
    }

    public static void onEditUsernameButtonClick() {
        ProfileService.editUsernameButton.addActionListener(event -> ProfileService.usernameField.setEditable(true));
    }

    public static void onEditEmailButtonClick() {
        ProfileService.editEmailButton.addActionListener(event -> ProfileService.emailField.setEditable(true));
    }

    public static void onEditPasswordButtonClick() {
        ProfileService.editPasswordButton.addActionListener(event -> ProfileService.passwordField.setEditable(true));
    }

    public static void onEditPhoneButtonClick() {
        ProfileService.editPhoneButton.addActionListener(event -> ProfileService.telephoneField.setEditable(true));
    }

    public static void onEditDobButtonClick() {
        ProfileService.editDobButton.addActionListener(event -> ProfileService.dobField.setEditable(true));
    }

    public static void onEditLocationButtonClick() {
        ProfileService.editLocationButton.addActionListener(event -> ProfileService.locationField.setEditable(true));
    }

    private static void onDeleteButtonClick() {
        try {
            UserProfile.profile = ImageIO.read(Objects.requireNonNull(GameController.class.getClassLoader().getResource("Welsh_Flag.gif")));
            ProfileService.photo.setIcon(new ImageIcon(UserProfile.profile));
            ProfileService.photo.revalidate();
            ProfileService.photo.repaint();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void onCancelButtonClick() {
        ProfileService.closeWindow();
    }
}
