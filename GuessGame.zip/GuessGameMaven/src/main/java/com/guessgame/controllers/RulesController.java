package com.guessgame.controllers;

import com.guessgame.services.RulesService;

public class RulesController {

    public static void performButtonHandlerAction(String cmd){
        if(cmd.equals("Ok")){
            onConfirmButtonClick();
        }
    }

    public static void onRulesClick(){
        RulesService.openWindow();
    }

    private static void onConfirmButtonClick(){
        RulesService.closeWindow();
    }
}
