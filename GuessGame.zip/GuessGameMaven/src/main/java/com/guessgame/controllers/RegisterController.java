package com.guessgame.controllers;

import com.google.firebase.auth.UserRecord;
import com.guessgame.models.AuthResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.guessgame.services.FirebaseService;
import com.guessgame.services.LoginService;
import com.guessgame.services.RegisterService;
import com.guessgame.services.UtilService;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class RegisterController {
    static Logger logger = LoggerFactory.getLogger(FirebaseService.class);

    static void onCancelButtonClick() {
        RegisterService.closeWindow();
        LoginService.openWindow();
    }

    public static void onRegisterButtonClick() {
        RegisterService.openWindow();
        LoginService.closeWindow();
    }

    static void onSignUpButtonClick() {
        boolean shouldContinueRegistration = true;
        if (RegisterService.emailField.getText().length() > 0 && !UtilService.isValidEmail(RegisterService.emailField.getText())) {
            shouldContinueRegistration = false;
        }
        if (RegisterService.telephoneField.getText().length() > 0 && !UtilService.isValidPhoneNumber(RegisterService.emailField.getText())) {
            shouldContinueRegistration = false;
        }
        if (!shouldContinueRegistration) {
            if (
                    RegisterService.firstNameField.getText().trim().length() == 0 ||
                            RegisterService.lastNameField.getText().trim().length() == 0 ||
                            RegisterService.usernameField.getText().trim().length() == 0 ||
                            String.valueOf(RegisterService.passwordField.getPassword()).length() == 0 ||
                            RegisterService.emailField.getText().trim().length() == 0 ||
                            RegisterService.telephoneField.getText().trim().length() == 0 ||
                            RegisterService.dobField.getText().trim().length() == 0 ||
                            Objects.requireNonNull(RegisterService.genderField.getSelectedItem()).toString().length() == 0 ||
                            RegisterService.locationField.getText().trim().length() == 0
            ) {
                JOptionPane.showMessageDialog(null, "You have not entered all fields, please try again.");
            } else {
                String firstName = RegisterService.firstNameField.getText();
                String lastName = RegisterService.lastNameField.getText();
                String username = RegisterService.usernameField.getText();
                String password = String.valueOf(RegisterService.passwordField.getPassword());
                String email = RegisterService.emailField.getText();
                String telephone = RegisterService.telephoneField.getText();
                String dob = RegisterService.dobField.getText();
                String gender = Objects.requireNonNull(RegisterService.genderField.getSelectedItem()).toString();
                String location = RegisterService.locationField.getText();
                createNewUser(firstName, lastName, username, password, email, telephone, dob, gender, location);
                JOptionPane.showMessageDialog(null, "Thank you. Your registration was successful!");
                RegisterService.closeWindow();
                LoginService.openWindow();
            }
        }
    }

    static void createNewUser(String firstName, String lastName, String username,
                              String password, String email, String telephone, String dob, String gender, String location) {
        try {
            UserRecord.CreateRequest userRecord = new UserRecord.CreateRequest();
            userRecord.setEmail(email);
            userRecord.setPassword(password);
            userRecord.setEmailVerified(true);
            userRecord.setDisabled(false);
            AuthResponse authResponse = FirebaseService.register(email, password);
            if (authResponse != null) {
                logger.debug(String.format("Created new user with uid %s", authResponse.getLocalId()));
                Map<String, Object> data = new HashMap<>();
                data.put("firstName", firstName);
                data.put("lastName", lastName);
                data.put("email", email);
                data.put("username", username);
                data.put("telephone", telephone);
                data.put("dob", dob);
                data.put("gender", gender);
                data.put("location", location);
                FirebaseService.createDocumentWithCustomUidAndObjectHashmap("users", authResponse.getLocalId(), data);
            }
        } catch (Exception e) {
            logger.debug(e.toString());
        }
    }
}