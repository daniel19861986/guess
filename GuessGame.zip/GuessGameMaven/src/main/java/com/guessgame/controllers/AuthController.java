package com.guessgame.controllers;

import com.guessgame.services.GameService;
import com.guessgame.services.LoginService;
import com.guessgame.services.RegisterService;

import java.awt.event.ItemEvent;
import java.sql.SQLException;

public class AuthController {
    public static void performButtonHandlerAction(String cmd) throws SQLException {
        if (cmd.equals(String.valueOf(LoginService.LoginText.LOGIN))) {
            LoginController.onLoginButtonClick();
        }
        if (cmd.equals(String.valueOf(LoginService.LoginText.REGISTER))) {
            System.exit(0);
        }
        if (cmd.equals(String.valueOf(RegisterService.RegisterText.SIGNUP))) {
            RegisterController.onSignUpButtonClick();
        }
        if (cmd.equals(String.valueOf(RegisterService.RegisterText.CANCEL))) {
            RegisterController.onCancelButtonClick();
        }
    }

    public static void performItemHandlerAction(ItemEvent event) {
        if (event.getItem() == LoginService.showPassword) {
            LoginController.onShowPasswordCheckboxClick();
        }
    }

    public static void onLogoutClick() {
        try {
            GameService.closeWindow();
            LoginService.openWindow();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
