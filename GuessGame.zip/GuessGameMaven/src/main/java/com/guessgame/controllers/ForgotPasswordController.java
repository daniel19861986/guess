package com.guessgame.controllers;

import com.guessgame.services.FirebaseService;
import com.guessgame.services.ForgotPasswordService;

import javax.swing.*;

public class ForgotPasswordController {
    public static void performButtonHandlerAction(String cmd) {
        if (cmd.equals(String.valueOf(ForgotPasswordService.ForgotPasswordTest.CONFIRM))) {
            onConfirmButtonClick();
        }
    }

    private static void onConfirmButtonClick() {
        if (ForgotPasswordService.emailTextField.getText().trim().length() == 0) {
            JOptionPane.showMessageDialog(null, "Please enter your email address to continue.");
        } else {
            FirebaseService.resetAccountPassword();
        }
    }
}
