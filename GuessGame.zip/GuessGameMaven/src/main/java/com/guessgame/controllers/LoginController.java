package com.guessgame.controllers;

import com.guessgame.models.AuthResponse;
import com.guessgame.models.User;
import com.guessgame.services.*;

import javax.swing.*;

public class LoginController {
    static void onLoginButtonClick() {
        String email = LoginService.emailField.getText();
        String password = String.valueOf(LoginService.passwordField.getPassword());
        AuthResponse authResponse = FirebaseService.login(email, password);
        if (authResponse == null) {
            JOptionPane.showMessageDialog(null, "Your login has been unsuccessful. Please try again.");
        } else {
            UserService.localId = authResponse.getLocalId();
            UserService.idToken = authResponse.getIdToken();
            User user = FirebaseService.getDocumentAsEntity("users", UserService.localId);
            if (user != null) {
                UserService.user = user;
                LoginService.closeWindow();
                GameService.openWindow();
            } else {
                JOptionPane.showMessageDialog(null, "An error has occurred. Please try to log in again.");
            }
        }
    }

    static void onShowPasswordCheckboxClick() {
        if (LoginService.showPassword.isSelected()) {
            LoginService.passwordField.setEchoChar((char) 0);
        } else {
            LoginService.passwordField.setEchoChar('*');
        }
    }

    public static void onLoginClick() {
        LoginService.openWindow();
        RegisterService.closeWindow();
    }

    public static void onForgotPasswordLabelClick() {
        ForgotPasswordService.openWindow();
    }
}